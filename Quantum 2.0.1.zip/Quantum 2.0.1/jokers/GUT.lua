
SMODS.Joker{ --Grand Unified Theory
    key = "GUT",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Grand Unified Theory',
        ['text'] = {
            [1] = 'All suits are considered',
            [2] = '1 Suit! A Grand Unified Theory',
            [3] = '(GUT) is any model in particle',
            [4] = 'physics that merges the',
            [5] = 'electromagnetic, weak, and',
            [6] = 'strong forces (the three',
                [7] = 'gauge interactions of the',
            [8] = 'Standard Model) into a',
            [9] = 'single force at high energies.',
            [10] = 'Although this unified force has',
            [11] = 'not been directly observed, many',
            [12] = 'GUT models theorize its existence.',
            [13] = 'If the unification of these three',
            [14] = 'interactions is possible, it raises',
            [15] = 'the possibility that there was a',
            [16] = 'grand unification epoch in',
            [17] = 'the very early universe',
            [18] = 'in which these three fundamental',
            [19] = 'interactions were not yet distinct.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 12,
    rarity = "quant_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true },
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        -- Combine suits effect enabled
        -- Combine suits effect enabled
        -- Combine suits effect enabled
        -- Combine suits effect enabled
        -- Combine suits effect enabled
        -- Combine suits effect enabled
        -- Combine suits effect enabled
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        -- Combine suits effect disabled
        -- Combine suits effect disabled
        -- Combine suits effect disabled
        -- Combine suits effect disabled
        -- Combine suits effect disabled
        -- Combine suits effect disabled
        -- Combine suits effect disabled
    end
}


local card_is_suit_ref = Card.is_suit
function Card:is_suit(suit, bypass_debuff, flush_calc)
    local ret = card_is_suit_ref(self, suit, bypass_debuff, flush_calc)
    if not ret and not SMODS.has_no_suit(self) then
        if next(SMODS.find_card("j_quant_GUT")) then
            -- If checking for Spades and card is Hearts, return true
            if suit == "Spades" and self.base.suit == "Hearts" then
                ret = true
            end
            -- If checking for Hearts and card is Spades, return true
            if suit == "Hearts" and self.base.suit == "Spades" then
                ret = true
            end
            -- If checking for Diamonds and card is Hearts, return true
            if suit == "Diamonds" and self.base.suit == "Hearts" then
                ret = true
            end
            -- If checking for Hearts and card is Diamonds, return true
            if suit == "Hearts" and self.base.suit == "Diamonds" then
                ret = true
            end
            -- If checking for Clubs and card is Hearts, return true
            if suit == "Clubs" and self.base.suit == "Hearts" then
                ret = true
            end
            -- If checking for Hearts and card is Clubs, return true
            if suit == "Hearts" and self.base.suit == "Clubs" then
                ret = true
            end
            -- If checking for Spades and card is Clubs, return true
            if suit == "Spades" and self.base.suit == "Clubs" then
                ret = true
            end
            -- If checking for Clubs and card is Spades, return true
            if suit == "Clubs" and self.base.suit == "Spades" then
                ret = true
            end
            -- If checking for Diamonds and card is Clubs, return true
            if suit == "Diamonds" and self.base.suit == "Clubs" then
                ret = true
            end
            -- If checking for Clubs and card is Diamonds, return true
            if suit == "Clubs" and self.base.suit == "Diamonds" then
                ret = true
            end
            -- If checking for Hearts and card is Clubs, return true
            if suit == "Hearts" and self.base.suit == "Clubs" then
                ret = true
            end
            -- If checking for Clubs and card is Hearts, return true
            if suit == "Clubs" and self.base.suit == "Hearts" then
                ret = true
            end
            -- If checking for Hearts and card is Diamonds, return true
            if suit == "Hearts" and self.base.suit == "Diamonds" then
                ret = true
            end
            -- If checking for Diamonds and card is Hearts, return true
            if suit == "Diamonds" and self.base.suit == "Hearts" then
                ret = true
            end
        end
    end
    return ret
end