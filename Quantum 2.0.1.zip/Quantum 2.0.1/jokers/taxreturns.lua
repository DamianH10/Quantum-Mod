
SMODS.Joker{ --Tax Returns
    key = "taxreturns",
    config = {
        extra = {
            money = 1
        }
    },
    loc_txt = {
        ['name'] = 'Tax Returns',
        ['text'] = {
            [1] = 'Gives {C:money}#1# ${} at the end of a',
            [2] = 'Round. Increases by 1 when',
            [3] = 'a Card is bought. The more',
            [4] = 'expenses you have, the less',
            [5] = 'tax you have to pay!'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_misc"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.money}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + card.ability.extra.money
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.money), colour = G.C.MONEY})
                    return true
                end
            }
        end
        if context.buying_card  then
            return {
                func = function()
                    card.ability.extra.money = (card.ability.extra.money) + 1
                    return true
                end
            }
        end
    end
}