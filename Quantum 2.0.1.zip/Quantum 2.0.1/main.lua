SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomConsumables", 
    path = "CustomConsumables.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomEnhancements", 
    path = "CustomEnhancements.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomSeals", 
    path = "CustomSeals.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
}):register()

SMODS.Atlas({
    key = "CustomVouchers", 
    path = "CustomVouchers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end

local jokerIndexList = {14,48,49,58,8,6,68,75,35,72,110,37,9,33,86,38,73,121,65,88,10,27,104,99,25,117,101,18,12,116,29,66,106,80,46,50,28,127,119,120,82,44,69,63,1,94,78,77,105,90,19,3,102,5,45,122,125,76,97,59,40,83,103,54,15,92,62,22,113,118,36,114,11,100,20,74,24,57,128,39,42,4,93,13,55,31,67,107,87,98,124,129,70,64,111,89,79,16,53,96,91,112,52,123,23,7,56,17,85,71,84,95,34,41,109,26,47,21,43,81,61,30,2,51,32,115,108,60,126}

local function load_jokers_folder()
    local mod_path = SMODS.current_mod.path
    local jokers_path = mod_path .. "/jokers"
    local files = NFS.getDirectoryItemsInfo(jokers_path)
    for i = 1, #jokerIndexList do
        local file_name = files[jokerIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("jokers/" .. file_name))()
        end
    end
end


local consumableIndexList = {12,11,4,6,10,13,17,23,15,2,1,9,8,3,19,16,14,7,22,21,18,20,5}

local function load_consumables_folder()
    local mod_path = SMODS.current_mod.path
    local consumables_path = mod_path .. "/consumables"
    local files = NFS.getDirectoryItemsInfo(consumables_path)
    local set_file_number = #files + 1
    for i = 1, #files do
        if files[i].name == "sets.lua" then
            assert(SMODS.load_file("consumables/sets.lua"))()
            set_file_number = i
        end
    end    
    for i = 1, #consumableIndexList do
        local j = consumableIndexList[i]
        if j >= set_file_number then 
            j = j + 1
        end
        local file_name = files[j].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("consumables/" .. file_name))()
        end
    end
end


local enhancementIndexList = {1}

local function load_enhancements_folder()
    local mod_path = SMODS.current_mod.path
    local enhancements_path = mod_path .. "/enhancements"
    local files = NFS.getDirectoryItemsInfo(enhancements_path)
    for i = 1, #enhancementIndexList do
        local file_name = files[enhancementIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("enhancements/" .. file_name))()
        end
    end
end


local sealIndexList = {1,4,5,6,7,8,9,10,11,3,2}

local function load_seals_folder()
    local mod_path = SMODS.current_mod.path
    local seals_path = mod_path .. "/seals"
    local files = NFS.getDirectoryItemsInfo(seals_path)
    for i = 1, #sealIndexList do
        local file_name = files[sealIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("seals/" .. file_name))()
        end
    end
end


local editionIndexList = {1}

local function load_editions_folder()
    local mod_path = SMODS.current_mod.path
    local editions_path = mod_path .. "/editions"
    local files = NFS.getDirectoryItemsInfo(editions_path)
    for i = 1, #editionIndexList do
        local file_name = files[editionIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("editions/" .. file_name))()
        end
    end
end


local voucherIndexList = {2,1,3,4}

local function load_vouchers_folder()
    local mod_path = SMODS.current_mod.path
    local vouchers_path = mod_path .. "/vouchers"
    local files = NFS.getDirectoryItemsInfo(vouchers_path)
    for i = 1, #voucherIndexList do
        local file_name = files[voucherIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("vouchers/" .. file_name))()
        end
    end
end


local deckIndexList = {5,8,6,4,7,11,2,3,9,1,10}

local function load_decks_folder()
    local mod_path = SMODS.current_mod.path
    local decks_path = mod_path .. "/decks"
    local files = NFS.getDirectoryItemsInfo(decks_path)
    for i = 1, #deckIndexList do
        local file_name = files[deckIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("decks/" .. file_name))()
        end
    end
end

local function load_rarities_file()
    local mod_path = SMODS.current_mod.path
    assert(SMODS.load_file("rarities.lua"))()
end

load_rarities_file()

local function load_boosters_file()
    local mod_path = SMODS.current_mod.path
    assert(SMODS.load_file("boosters.lua"))()
end

load_boosters_file()
load_jokers_folder()
load_consumables_folder()
load_enhancements_folder()
load_seals_folder()
load_editions_folder()
load_vouchers_folder()
load_decks_folder()
SMODS.ObjectType({
    key = "quant_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "quant_quant_jokers",
    cards = {
        ["j_quant_Al"] = true,
        ["j_quant_anyon"] = true,
        ["j_quant_Ar"] = true,
        ["j_quant_As"] = true,
        ["j_quant_axion"] = true,
        ["j_quant_B"] = true,
        ["j_quant_Ba"] = true,
        ["j_quant_Be"] = true,
        ["j_quant_Bitcoin"] = true,
        ["j_quant_BlackHole"] = true,
        ["j_quant_boseeinsteincondensate"] = true,
        ["j_quant_BottomQuark"] = true,
        ["j_quant_bromine"] = true,
        ["j_quant_C"] = true,
        ["j_quant_Ca"] = true,
        ["j_quant_cd"] = true,
        ["j_quant_Ce"] = true,
        ["j_quant_CharmQuark"] = true,
        ["j_quant_Cl"] = true,
        ["j_quant_Co"] = true,
        ["j_quant_cosmon"] = true,
        ["j_quant_Cr"] = true,
        ["j_quant_Cs"] = true,
        ["j_quant_Cu"] = true,
        ["j_quant_DownQuark"] = true,
        ["j_quant_Dy"] = true,
        ["j_quant_DyingStar"] = true,
        ["j_quant_electromagnetism"] = true,
        ["j_quant_electron"] = true,
        ["j_quant_electronhole"] = true,
        ["j_quant_electronneutrino"] = true,
        ["j_quant_Er"] = true,
        ["j_quant_ETH"] = true,
        ["j_quant_Eu"] = true,
        ["j_quant_F"] = true,
        ["j_quant_Fe"] = true,
        ["j_quant_FP"] = true,
        ["j_quant_FractalGeometry"] = true,
        ["j_quant_Ga"] = true,
        ["j_quant_gaseousstate"] = true,
        ["j_quant_Gd"] = true,
        ["j_quant_Ge"] = true,
        ["j_quant_glueball"] = true,
        ["j_quant_gluon"] = true,
        ["j_quant_graviton"] = true,
        ["j_quant_gravity"] = true,
        ["j_quant_GUT"] = true,
        ["j_quant_H"] = true,
        ["j_quant_He"] = true,
        ["j_quant_higgs"] = true,
        ["j_quant_Ho"] = true,
        ["j_quant_I"] = true,
        ["j_quant_In"] = true,
        ["j_quant_K"] = true,
        ["j_quant_Kr"] = true,
        ["j_quant_La"] = true,
        ["j_quant_leptoquark"] = true,
        ["j_quant_Li"] = true,
        ["j_quant_liquidstate"] = true,
        ["j_quant_loan"] = true,
        ["j_quant_majoranaparticle"] = true,
        ["j_quant_meme"] = true,
        ["j_quant_Mg"] = true,
        ["j_quant_Mo"] = true,
        ["j_quant_MTO"] = true,
        ["j_quant_muon"] = true,
        ["j_quant_muonneutrino"] = true,
        ["j_quant_N"] = true,
        ["j_quant_Na"] = true,
        ["j_quant_Nb"] = true,
        ["j_quant_Nd"] = true,
        ["j_quant_Ne"] = true,
        ["j_quant_NeutronStar"] = true,
        ["j_quant_Ni"] = true,
        ["j_quant_O"] = true,
        ["j_quant_omgparticle"] = true,
        ["j_quant_omiverse"] = true,
        ["j_quant_P"] = true,
        ["j_quant_Pd"] = true,
        ["j_quant_pentaquark"] = true,
        ["j_quant_phonon"] = true,
        ["j_quant_photon"] = true,
        ["j_quant_plasma"] = true,
        ["j_quant_Pm"] = true,
        ["j_quant_Pr"] = true,
        ["j_quant_QuantumEntanglement"] = true,
        ["j_quant_Rb"] = true,
        ["j_quant_reportcard"] = true,
        ["j_quant_Ru"] = true,
        ["j_quant_S"] = true,
        ["j_quant_Sb"] = true,
        ["j_quant_Sc"] = true,
        ["j_quant_Se"] = true,
        ["j_quant_Si"] = true,
        ["j_quant_Sm"] = true,
        ["j_quant_Sn"] = true,
        ["j_quant_solidstate"] = true,
        ["j_quant_Sr"] = true,
        ["j_quant_star"] = true,
        ["j_quant_sterileneutrino"] = true,
        ["j_quant_StrangeQuark"] = true,
        ["j_quant_stringtheory"] = true,
        ["j_quant_superfluidity"] = true,
        ["j_quant_SupermassiveStar"] = true,
        ["j_quant_tachyon"] = true,
        ["j_quant_tau"] = true,
        ["j_quant_tauneutrino"] = true,
        ["j_quant_taxreturns"] = true,
        ["j_quant_Tb"] = true,
        ["j_quant_TBL"] = true,
        ["j_quant_Tc"] = true,
        ["j_quant_Te"] = true,
        ["j_quant_Ti"] = true,
        ["j_quant_timecrystal"] = true,
        ["j_quant_Tm"] = true,
        ["j_quant_TopQuark"] = true,
        ["j_quant_UpQuark"] = true,
        ["j_quant_V"] = true,
        ["j_quant_wboson"] = true,
        ["j_quant_wboson2"] = true,
        ["j_quant_Weak"] = true,
        ["j_quant_xboson"] = true,
        ["j_quant_Xe"] = true,
        ["j_quant_Y"] = true,
        ["j_quant_yboson"] = true,
        ["j_quant_ytterbium"] = true,
        ["j_quant_zboson"] = true,
        ["j_quant_Zn"] = true,
        ["j_quant_Zr"] = true
    },
})

SMODS.ObjectType({
    key = "quant_element",
    cards = {
        ["j_quant_Al"] = true,
        ["j_quant_Ar"] = true,
        ["j_quant_As"] = true,
        ["j_quant_B"] = true,
        ["j_quant_Ba"] = true,
        ["j_quant_Be"] = true,
        ["j_quant_bromine"] = true,
        ["j_quant_C"] = true,
        ["j_quant_Ca"] = true,
        ["j_quant_cd"] = true,
        ["j_quant_Ce"] = true,
        ["j_quant_Cl"] = true,
        ["j_quant_Co"] = true,
        ["j_quant_Cr"] = true,
        ["j_quant_Cs"] = true,
        ["j_quant_Cu"] = true,
        ["j_quant_Dy"] = true,
        ["j_quant_Er"] = true,
        ["j_quant_Eu"] = true,
        ["j_quant_F"] = true,
        ["j_quant_Fe"] = true,
        ["j_quant_Gd"] = true,
        ["j_quant_Ge"] = true,
        ["j_quant_H"] = true,
        ["j_quant_He"] = true,
        ["j_quant_Ho"] = true,
        ["j_quant_I"] = true,
        ["j_quant_In"] = true,
        ["j_quant_K"] = true,
        ["j_quant_Kr"] = true,
        ["j_quant_La"] = true,
        ["j_quant_Li"] = true,
        ["j_quant_Mg"] = true,
        ["j_quant_Mo"] = true,
        ["j_quant_N"] = true,
        ["j_quant_Na"] = true,
        ["j_quant_Nb"] = true,
        ["j_quant_Nd"] = true,
        ["j_quant_Ne"] = true,
        ["j_quant_Ni"] = true,
        ["j_quant_O"] = true,
        ["j_quant_P"] = true,
        ["j_quant_Pd"] = true,
        ["j_quant_Pm"] = true,
        ["j_quant_Pr"] = true,
        ["j_quant_Rb"] = true,
        ["j_quant_Ru"] = true,
        ["j_quant_S"] = true,
        ["j_quant_Sb"] = true,
        ["j_quant_Sc"] = true,
        ["j_quant_Se"] = true,
        ["j_quant_Si"] = true,
        ["j_quant_Sm"] = true,
        ["j_quant_Sn"] = true,
        ["j_quant_Sr"] = true,
        ["j_quant_Tb"] = true,
        ["j_quant_Tc"] = true,
        ["j_quant_Te"] = true,
        ["j_quant_Ti"] = true,
        ["j_quant_Tm"] = true,
        ["j_quant_V"] = true,
        ["j_quant_Xe"] = true,
        ["j_quant_Y"] = true,
        ["j_quant_ytterbium"] = true,
        ["j_quant_Zn"] = true,
        ["j_quant_Zr"] = true
    },
})

SMODS.ObjectType({
    key = "quant_util",
    cards = {
        ["j_quant_Al"] = true,
        ["j_quant_Ba"] = true,
        ["j_quant_Bitcoin"] = true,
        ["j_quant_Ca"] = true,
        ["j_quant_Cs"] = true,
        ["j_quant_ETH"] = true,
        ["j_quant_gluon"] = true,
        ["j_quant_gravity"] = true,
        ["j_quant_I"] = true,
        ["j_quant_Mg"] = true,
        ["j_quant_MTO"] = true,
        ["j_quant_N"] = true,
        ["j_quant_S"] = true,
        ["j_quant_Sn"] = true,
        ["j_quant_Tb"] = true,
        ["j_quant_Ti"] = true,
        ["j_quant_V"] = true,
        ["j_quant_Weak"] = true
    },
})

SMODS.ObjectType({
    key = "quant_misc",
    cards = {
        ["j_quant_Bitcoin"] = true,
        ["j_quant_BlackHole"] = true,
        ["j_quant_DyingStar"] = true,
        ["j_quant_ETH"] = true,
        ["j_quant_FP"] = true,
        ["j_quant_FractalGeometry"] = true,
        ["j_quant_loan"] = true,
        ["j_quant_meme"] = true,
        ["j_quant_MTO"] = true,
        ["j_quant_NeutronStar"] = true,
        ["j_quant_reportcard"] = true,
        ["j_quant_star"] = true,
        ["j_quant_SupermassiveStar"] = true,
        ["j_quant_taxreturns"] = true,
        ["j_quant_TBL"] = true
    },
})

SMODS.ObjectType({
    key = "quant_elemen",
    cards = {
        ["j_quant_Ga"] = true
    },
})

SMODS.ObjectType({
    key = "quant_state",
    cards = {
        ["j_quant_gaseousstate"] = true,
        ["j_quant_liquidstate"] = true,
        ["j_quant_superfluidity"] = true
    },
})

SMODS.ObjectType({
    key = "quant_states",
    cards = {
        ["j_quant_solidstate"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {},
        post_trigger = true 
    }
end