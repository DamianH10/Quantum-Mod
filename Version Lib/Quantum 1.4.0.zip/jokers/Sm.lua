
SMODS.Joker{ --Samarium
    key = "Sm",
    config = {
        extra = {
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Samarium',
        ['text'] = {
            [1] = 'This card starts at {X:mult,C:white}×1{} {C:red}Mult{},',
            [2] = 'every hand played this card',
            [3] = 'gains {C:red}+0.05 XMult{}. Current {C:red}XMult{}:',
            [4] = '{X:mult,C:white}×#1#{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_element"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xmult}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            card.ability.extra.xmult = (card.ability.extra.xmult) + 0.05
            return {
                Xmult = card.ability.extra.xmult
            }
        end
    end
}