
SMODS.Joker{ --Europium
    key = "Eu",
    config = {
        extra = {
            Xchipmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Europium',
        ['text'] = {
            [1] = 'When a card is Discarded',
            [2] = 'this card gains {C:legendary}+0.005{}',
            [3] = '{C:red}XMult{} and {C:blue}XChips{}. Current:',
            [4] = '{X:tarot,C:white}×#1#{}',
            [5] = 'Fun fact, I (the mod',
            [6] = 'creator) am actually European'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 12,
    rarity = "quant_ultra_rare",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_element"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Xchipmult}}
    end,
    
    calculate = function(self, card, context)
        if context.discard  then
            return {
                func = function()
                    card.ability.extra.Xchipmult = (card.ability.extra.Xchipmult) + 0.005
                    return true
                end
            }
        end
        if context.individual and context.cardarea == G.play  then
            return {
                x_chips = card.ability.extra.Xchipmult,
                extra = {
                    Xmult = card.ability.extra.Xchipmult
                }
            }
        end
    end
}