
SMODS.Joker{ --Neodymium
    key = "Nd",
    config = {
        extra = {
            xchips0 = 1.5,
            xchips = 2,
            xchips2 = 2.5,
            xchips3 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Neodymium',
        ['text'] = {
            [1] = 'If Played hand contains',
            [2] = 'at least 2 Cards: {X:chips,C:white}×1.5{}',
            [3] = '{C:blue}Chips{}. If Played hand',
            [4] = 'contains at least 3 Cards:',
            [5] = '{X:chips,C:white}×2{} {C:blue}Chips{} and etc.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_element"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#context.scoring_hand) >= to_big(2) then
                return {
                    x_chips = 1.5
                }
            elseif to_big(#context.scoring_hand) >= to_big(3) then
                return {
                    x_chips = 2
                }
            elseif to_big(#context.scoring_hand) >= to_big(4) then
                return {
                    x_chips = 2.5
                }
            elseif to_big(#context.scoring_hand) >= to_big(5) then
                return {
                    x_chips = 3
                }
            end
        end
    end
}