
SMODS.Joker{ --Promethium
    key = "Pm",
    config = {
        extra = {
            Mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Promethium',
        ['text'] = {
            [1] = 'This Card gains {C:red}+1 Mult{}',
            [2] = 'whan another Joker is',
            [3] = 'Triggered. Current Mult:',
            [4] = '{X:red,C:white}#1#{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 12,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_element"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Mult}}
    end,
    
    calculate = function(self, card, context)
        if context.post_trigger  then
            return {
                func = function()
                    card.ability.extra.Mult = (card.ability.extra.Mult) + 1
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.Mult
            }
        end
    end
}