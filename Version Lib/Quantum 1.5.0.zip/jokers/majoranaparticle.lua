
SMODS.Joker{ --Majorana Particle
    key = "majoranaparticle",
    config = {
        extra = {
            repetitions0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Majorana Particle',
        ['text'] = {
            [1] = 'If Played hand contains a',
            [2] = 'Pair, Nothing happens. Else',
            [3] = 'retrigger every card 4 times',
            [4] = 'Note: This image is the',
            [5] = 'Majorana Chip for quantum',
            [6] = 'computer Chips using the',
            [7] = 'Majorana particle.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 14,
    rarity = "quant_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if not (next(context.poker_hands["Pair"])) then
                return {
                    repetitions = 4,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}