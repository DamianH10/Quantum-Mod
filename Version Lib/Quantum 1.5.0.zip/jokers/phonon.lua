
SMODS.Joker{ --Phonon
    key = "phonon",
    config = {
        extra = {
            uncommonjokers = 0
        }
    },
    loc_txt = {
        ['name'] = 'Phonon',
        ['text'] = {
            [1] = '1 Retrigger Every card',
            [2] = 'as many times as you',
            [3] = 'have {C:uncommon}Uncommon{} Jokers.',
            [4] = 'I AM NOT EXPLAINING',
            [5] = 'PHONOS, NO THANK YOU!',
            [6] = 'its something like a',
            [7] = 'quantized sound wave btw.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 14,
    rarity = "quant_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
    return {vars = {(function() local count = 0; for _, joker in ipairs(G.jokers and (G.jokers and G.jokers.cards or {}) or {}) do if joker.config.center.rarity == 2 then count = count + 1 end end; return count end)()}}
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            return {
            repetitions = (function() local count = 0; for _, joker in ipairs(G.jokers and G.jokers.cards or {}) do if joker.config.center.rarity == 2 then count = count + 1 end end; return count end)(),
                message = localize('k_again_ex')
            }
        end
    end
}