
SMODS.Joker{ --Gadolinium
    key = "Gd",
    config = {
        extra = {
            xchips = 1
        }
    },
    loc_txt = {
        ['name'] = 'Gadolinium',
        ['text'] = {
            [1] = 'This card starts at {X:chips,C:white}×1{} {C:blue}Chips{},',
            [2] = 'every hand played this card',
            [3] = 'gains {C:blue}+0.05 XChips{}. Current {C:blue}XChips{}:',
            [4] = '{X:chips,C:white}×#1#{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_element"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xchips}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            card.ability.extra.xchips = (card.ability.extra.xchips) + 0.05
            return {
                x_chips = card.ability.extra.xchips
            }
        end
    end
}