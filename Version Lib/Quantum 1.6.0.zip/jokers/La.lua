
SMODS.Joker{ --Lanthanum
    key = "La",
    config = {
        extra = {
            xchips = 1,
            odds = 15
        }
    },
    loc_txt = {
        ['name'] = 'Lanthanum',
        ['text'] = {
            [1] = 'When a Card is sold:',
            [2] = '{C:green}#2# in #3#{} Chance to',
            [3] = 'add {X:chips,C:white}×0.25{} {C:blue}X-Chips{}.',
            [4] = 'Current {C:blue}X-Chips{}:',
            [5] = '{X:chips,C:white}×#1#{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_element"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quant_La') 
        return {vars = {card.ability.extra.xchips, new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.selling_card  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_c4421d85', 1, card.ability.extra.odds, 'j_quant_La', false) then
                    SMODS.calculate_effect({func = function()
                        card.ability.extra.xchips = (card.ability.extra.xchips) + 0.25
                        return true
                    end}, card)
                end
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                x_chips = card.ability.extra.xchips
            }
        end
    end
}