
SMODS.Joker{ --Terbium
    key = "Tb",
    config = {
        extra = {
            reroll_amount = '4',
            discards_change = '1',
            xchips = 1
        }
    },
    loc_txt = {
        ['name'] = 'Terbium',
        ['text'] = {
            [1] = '{C:green}+4 Free Rerolls{} BUT {C:red}-1 Discard{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_element"] = true, ["quant_util"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xchips}}
    end,
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        SMODS.change_free_rerolls(4)
        G.GAME.round_resets.discards = math.max(1, G.GAME.round_resets.discards - 1)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_free_rerolls(-(4))
        G.GAME.round_resets.discards = G.GAME.round_resets.discards + 1
    end
}