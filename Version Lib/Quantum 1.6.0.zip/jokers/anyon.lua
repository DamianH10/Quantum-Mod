
SMODS.Joker{ --Anyon
    key = "anyon",
    config = {
        extra = {
            odds = 2,
            odds2 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Anyon',
        ['text'] = {
            [1] = 'When Boss is defeated {C:green}#1# in #2#{} Chance to',
            [2] = 'create a {C:hearts}Ultra Rare{} Joker and a {C:green}#3# in #4#{}',
            [3] = 'chance to create a {C:planet}MYTHIC{} Joker.',
            [4] = 'In physics, an anyon is a type of quasiparticle',
            [5] = 'so far observed only in two-dimensional',
            [6] = 'systems. In three-dimensional systems,',
            [7] = 'only two kinds of elementary particles are seen:',
            [8] = 'fermions and bosons. Anyons have statistical',
            [9] = 'properties intermediate between fermions and',
            [10] = 'bosons. In general, the operation of exchanging',
            [11] = 'two identical particles, although it may cause',
            [12] = 'a global phase shift, cannot affect observables.',
            [13] = 'Anyons are generally classified as abelian or',
            [14] = 'non-abelian. Abelian anyons, detected by two',
            [15] = 'experiments in 2020,[2] play a major  role in',
            [16] = 'the fractional quantum Hall effect.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 18,
    rarity = "quant_exotic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quant_anyon')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_quant_anyon')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_8230b50d', 1, card.ability.extra.odds, 'j_quant_anyon', false) then
                    SMODS.calculate_effect({func = function()
                        
                        local created_joker = false
                        if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                            created_joker = true
                            G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'quant_ultra_rare' })
                                    if joker_card then
                                        
                                        
                                    end
                                    G.GAME.joker_buffer = 0
                                    return true
                                end
                            }))
                        end
                        if created_joker then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                        end
                        return true
                    end}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_1_69d8335e', 1, card.ability.extra.odds2, 'j_quant_anyon', false) then
                    SMODS.calculate_effect({func = function()
                        
                        local created_joker = false
                        if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                            created_joker = true
                            G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'quant_mythic' })
                                    if joker_card then
                                        
                                        
                                    end
                                    G.GAME.joker_buffer = 0
                                    return true
                                end
                            }))
                        end
                        if created_joker then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                        end
                        return true
                    end}, card)
                end
            end
        end
    end
}