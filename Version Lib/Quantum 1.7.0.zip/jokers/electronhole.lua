
SMODS.Joker{ --Electron Hole
    key = "electronhole",
    config = {
        extra = {
            xmult0 = 3,
            xmult = 25
        }
    },
    loc_txt = {
        ['name'] = 'Electron Hole',
        ['text'] = {
            [1] = 'If you have no Consumables',
            [2] = '{X:mult,C:white}×3{} {C:red}Mult{}, But if you have',
            [3] = 'NO MONEY {X:red,C:white}×25{} {C:red}Mult{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#G.consumeables.cards) == to_big(0) then
                return {
                    Xmult = 3
                }
            elseif to_big(G.GAME.dollars) == to_big(0) then
                return {
                    Xmult = 25
                }
            end
        end
    end
}