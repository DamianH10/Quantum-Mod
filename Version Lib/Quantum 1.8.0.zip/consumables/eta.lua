
SMODS.Consumable {
    key = 'eta',
    set = '_subatomic_particle',
    pos = { x = 7, y = 1 },
    config = { 
        extra = {
            hands0 = 1   
        } 
    },
    loc_txt = {
        name = 'Eta',
        text = {
            [1] = '{C:attention}+1{} permanent hand.'
        }
    },
    cost = 4,
    unlocked = true,
    discovered = false,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            
            func = function()
                card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Hands", colour = G.C.GREEN})
                
                G.GAME.round_resets.hands = G.GAME.round_resets.hands + 1
                ease_hands_played(1)
                
                return true
            end
        }))
        delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}