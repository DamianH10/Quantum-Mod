
SMODS.Joker{ --Erbium
    key = "Er",
    config = {
        extra = {
            xmult0 = 1.5,
            xchips0 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Erbium',
        ['text'] = {
            [1] = 'Odd cards give {X:mult,C:white}×1.5{} {C:red}X Mult{}',
            [2] = 'Even Cards give {X:chips,C:white}×1.5{} {C:blue}X Chips{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_element"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 14 or context.other_card:get_id() == 3 or context.other_card:get_id() == 5 or context.other_card:get_id() == 7 or context.other_card:get_id() == 9) then
                return {
                    Xmult = 1.5
                }
            elseif (context.other_card:get_id() == 2 or context.other_card:get_id() == 4 or context.other_card:get_id() == 6 or context.other_card:get_id() == 8 or context.other_card:get_id() == 10) then
                return {
                    x_chips = 1.5
                }
            end
        end
    end
}