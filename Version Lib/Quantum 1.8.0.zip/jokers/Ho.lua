
SMODS.Joker{ --Holmium
    key = "Ho",
    config = {
        extra = {
            currentante = 0
        }
    },
    loc_txt = {
        ['name'] = 'Holmium',
        ['text'] = {
            [1] = 'Gain {C:red}X Mult{} based on',
            [2] = 'current ante.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_element"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(G.GAME.round_resets.ante or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = G.GAME.round_resets.ante,
                extra = {
                    x_chips = G.GAME.round_resets.ante,
                    colour = G.C.DARK_EDITION
                }
            }
        end
    end
}