
SMODS.Joker{ --Thulium
    key = "Tm",
    config = {
        extra = {
            xmult0 = 1.75
        }
    },
    loc_txt = {
        ['name'] = 'Thulium',
        ['text'] = {
            [1] = 'Gain {X:mult,C:white}×1.75{} {C:red}X Mult{} if the',
            [2] = 'scored card isn\'t a face card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_element"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if not (context.other_card:is_face()) then
                return {
                    Xmult = 1.75
                }
            end
        end
    end
}