
SMODS.Joker{ --Cosmon
    key = "cosmon",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Cosmon',
        ['text'] = {
            [1] = 'Literraly the whole universe.',
            [2] = 'Anyways, you  just win.',
            [3] = 'yea thats it kinda...'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "quant_extra_dimensional_transient_ultima_supreme_hyper_exotic_arcane_limitless_omniversal_unmatched_deity_infinitecimal_unknowable_infinty_",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.buying_card and context.card.config.center.key == self.key and context.cardarea == G.jokers  then
            G.E_MANAGER:add_event(Event({
                blocking = false,
                func = function()
                    if G.STATE == G.STATES.SELECTING_HAND then
                        G.GAME.chips = G.GAME.blind.chips
                        G.STATE = G.STATES.HAND_PLAYED
                        G.STATE_COMPLETE = true
                        end_round()
                        return true
                    end
                end
            }))
            return {
                message = "Win!"
            }
        end
    end
}