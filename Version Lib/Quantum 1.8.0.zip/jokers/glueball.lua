
SMODS.Joker{ --Glueball
    key = "glueball",
    config = {
        extra = {
            freeconsumableslots = 0
        }
    },
    loc_txt = {
        ['name'] = 'Glueball',
        ['text'] = {
            [1] = 'Retriggers Every Card as',
            [2] = 'many times as Free',
            [3] = 'consumable slots are left.',
            [4] = 'A big particle made completely',
            [5] = 'out of Gluons, could actually',
            [6] = 'exist in real life!'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 12,
    rarity = "quant_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(((G.consumeables and G.consumeables.config.card_limit or 0) - #(G.consumeables and G.consumeables.cards or {})) or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            return {
                repetitions = ((G.consumeables and G.consumeables.config.card_limit or 0) - #(G.consumeables and G.consumeables.cards or {})),
                message = localize('k_again_ex')
            }
        end
    end
}