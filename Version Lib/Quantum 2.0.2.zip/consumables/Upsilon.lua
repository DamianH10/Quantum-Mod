
SMODS.Consumable {
    key = 'Upsilon',
    set = '_subatomic_particle',
    pos = { x = 8, y = 1 },
    loc_txt = {
        name = 'Upsilon',
        text = {
            [1] = 'Create a random modded Joker'
        }
    },
    cost = 2,
    unlocked = true,
    discovered = false,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
                play_sound('timpani')
                local new_joker = SMODS.add_card({ set = 'quant_quant_jokers' })
                if new_joker then
                end
                used_card:juice_up(0.3, 0.5)
                return true
            end
        }))
        delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}