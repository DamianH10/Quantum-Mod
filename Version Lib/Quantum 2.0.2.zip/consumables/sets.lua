SMODS.ConsumableType {
    key = '_subatomic_particle',
    primary_colour = HEX('1d9a76'),
    secondary_colour = HEX('1d9a76'),
    collection_rows = { 4, 5 },
    shop_rate = 0.5,
    cards = {
        ['c_quant_Lambda'] = true,
        ['c_quant_Delta Baryon'] = true,
        ['c_quant_dmeson'] = true,
        ['c_quant_kaon'] = true,
        ['c_quant_Omega Baryon'] = true,
        ['c_quant_pion'] = true,
        ['c_quant_Xi Baryon'] = true,
        ['c_quant_rho'] = true,
        ['c_quant_phi'] = true,
        ['c_quant_omegameson'] = true,
        ['c_quant_eta'] = true,
        ['c_quant_Upsilon'] = true,
        ['c_quant_thetameson'] = true,
        ['c_quant_psimeson'] = true,
        ['c_quant_sigmabaryon'] = true
    },
    loc_txt = {
        name = " Subatomic Particle",
        collection = " Subatomic Particle Cards",
    }
}

SMODS.ConsumableType {
    key = 'chemical',
    primary_colour = HEX('000692'),
    secondary_colour = HEX('000692'),
    collection_rows = { 4, 5 },
    shop_rate = 1.1,
    cards = {
        ['c_quant_N6'] = true,
        ['c_quant_ozone'] = true,
        ['c_quant_buckminsterfullerene'] = true,
        ['c_quant_flouroantimonicacid'] = true,
        ['c_quant_f2'] = true,
        ['c_quant_COCl2'] = true,
        ['c_quant_dimethylmercury'] = true
    },
    loc_txt = {
        name = "Chemical",
        collection = "Chemical Cards",
    }
}

SMODS.ConsumableType {
    key = 'isotope',
    primary_colour = HEX('417505'),
    secondary_colour = HEX('417505'),
    collection_rows = { 4, 5 },
    shop_rate = 0.8,
    cards = {
        ['c_quant_carbon12metastable'] = true
    },
    loc_txt = {
        name = "Isotope",
        collection = "Isotope Cards",
    }
}