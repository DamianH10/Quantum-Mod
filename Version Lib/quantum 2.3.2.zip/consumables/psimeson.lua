
SMODS.Consumable {
    key = 'psimeson',
    set = '_subatomic_particle',
    pos = { x = 0, y = 2 },
    loc_txt = {
        name = 'Psi Meson',
        text = {
            [1] = 'Redeem a random',
            [2] = 'Voucher when used'
        }
    },
    cost = 4,
    unlocked = true,
    discovered = false,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        local voucher_key = pseudorandom_element(G.P_CENTER_POOLS.Voucher, "a61c715c").key
        local voucher_card = SMODS.create_card{area = G.play, key = voucher_key}
        voucher_card:start_materialize()
        voucher_card.cost = 0
        G.play:emplace(voucher_card)
        delay(0.8)
        voucher_card:redeem()
        
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.5,
            func = function()
                voucher_card:start_dissolve()                
                return true
            end
        }))
        return {
            message = nil
        }
    end,
    can_use = function(self, card)
        return true
    end
}