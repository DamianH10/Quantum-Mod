
SMODS.Consumable {
    key = 'sigmabaryon',
    set = '_subatomic_particle',
    pos = { x = 1, y = 2 },
    config = { 
        extra = {
            shop_slots0 = 1   
        } 
    },
    loc_txt = {
        name = 'Sigma baryon',
        text = {
            [1] = 'Gain {C:attention}+1{} Permanent',
            [2] = 'Shop card slot.'
        }
    },
    cost = 8,
    unlocked = true,
    discovered = false,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
                card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Shop Slots", colour = G.C.BLUE})
                
                change_shop_size(1)
                return true
            end
        }))
        delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}