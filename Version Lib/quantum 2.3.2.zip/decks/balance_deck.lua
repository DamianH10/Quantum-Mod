
SMODS.Back {
    key = 'balance_deck',
    pos = { x = 9, y = 0 },
    config = {
    },
    loc_txt = {
        name = 'Balance Deck',
        text = {
            [1] = '{C:blue}+1 Hand{}, {C:red}+1 Discard{}',
            [2] = '{C:money}+1 Starting ${} But',
            [3] = 'Winner {C:attention}Ante{} is 10'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
        G.GAME.starting_params.dollars = 5
        G.GAME.win_ante = 10
    end
}