
SMODS.Back {
    key = 'scale_deck_js',
    pos = { x = 0, y = 1 },
    config = {
    },
    loc_txt = {
        name = 'Scale Deck JS',
        text = {
            [1] = 'Start with {C:dark_edition}-3{} Joker slots',
            [2] = 'but {C:dark_edition}+1{} Joker slot when a',
            [3] = 'boss blind is beaten'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            G.GAME.starting_params.joker_slots = G.GAME.starting_params.joker_slots + 1
        end
    end,
    apply = function(self, back)
        G.GAME.starting_params.joker_slots = G.GAME.starting_params.joker_slots - 3
    end
}