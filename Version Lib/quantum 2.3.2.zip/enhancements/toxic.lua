
SMODS.Enhancement {
    key = 'toxic',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            xchips0 = 3,
            odds = 50
        }
    },
    loc_txt = {
        name = 'Toxic',
        text = {
            [1] = '{C:green} 3X Chips, But there is a {}',
            [2] = '{C:green}#1# in #2# Chance to {}',
            [3] = '{C:green}the card is destroyed{}'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    shatters = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = false,
    no_collection = false,
    weight = 0,
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            return { remove = true }
        end
        if context.main_scoring and context.cardarea == G.play then
            return {
                x_chips = 3
            }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            if SMODS.pseudorandom_probability(card, 'group_0_c1919a43', 1, card.ability.extra.odds, 'j_quantum_toxic', false) then
                context.other_card.should_destroy = true
                card.should_destroy = true
                
            end
        end
    end
}