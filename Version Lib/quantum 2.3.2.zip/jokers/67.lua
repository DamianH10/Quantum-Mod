
SMODS.Joker{ --SIX SEVEN!!!!!
    key = "67",
    config = {
        extra = {
            odds = 100,
            xmult0 = 1.67
        }
    },
    loc_txt = {
        ['name'] = 'SIX SEVEN!!!!!',
        ['text'] = {
            [1] = 'why did I even make this card',
            [2] = 'Every {C:attention}6{} or {C:attention}7{} has a {C:green}67%{} chance',
            [3] = 'to give {X:red,C:white}×1.67{} {C:red}XMult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 67,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_misc"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 67, card.ability.extra.odds, 'j_quantum_67') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_f1b60bf1', 67, card.ability.extra.odds, 'j_quantum_67', false) then
                    SMODS.calculate_effect({Xmult = 1.67}, card)
                end
            end
        end
    end
}