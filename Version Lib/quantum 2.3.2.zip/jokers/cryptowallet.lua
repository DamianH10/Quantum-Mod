
SMODS.Joker{ --Crypto wallet
    key = "cryptowallet",
    config = {
        extra = {
            Bitcoin = 0,
            dollars0 = 5,
            xmult0 = 0.5,
            xmult = 2,
            discards0 = 2,
            levels0 = 1,
            joker_slots0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Crypto wallet',
        ['text'] = {
            [1] = '{C:red}SPECIAL CARD!{} Adds Cryptocurrency.',
            [2] = 'Current {C:hearts}B:{} {C:hearts} #1# {}',
            [3] = 'Move to the very left to activate special',
            [4] = 'abilities (or SA for short). Brace yourself:',
            [5] = '1. if bitcoin is present gain {C:hearts}1 B{} very round',
            [6] = '2. SA for buying a card: {C:hearts}-1B{} and get {C:money}5${} back',
            [7] = '3. SA when hand is played: {C:red}0.5X Mult{} {C:hearts}+2 B{}',
            [8] = '4. When placed in second slot: {C:red}2X Mult{} {C:hearts}-2 B{}',
            [9] = '5. When a Booster pack is skipped {C:hearts}+1 B{}',
            [10] = '6. When in boss blind select joker to disable it (for {C:hearts}1.5 B{})',
            [11] = '7. When entering a blind select this joker for {C:red}+2 Discards{} {C:hearts}-0.5 B{}',
            [12] = '8. On Reroll {C:hearts}+0.1 B{} or if selected level up the last played hand',
            [13] = '9. If slected and entring a shop: {C:hearts}-100 B{} {C:dark_edition}+ 1 Joker Slot{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Bitcoin}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_Bitcoin" then 
                        return true
                    end
                end
            end)() then
                return {
                    func = function()
                        card.ability.extra.Bitcoin = (card.ability.extra.Bitcoin) + 1
                        return true
                    end
                }
            end
        end
        if context.buying_card  then
            if ((function()
                return G.jokers.cards[1] == card
            end)() and to_big((card.ability.extra.Bitcoin or 0)) >= to_big(1)) then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 5
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(5), colour = G.C.MONEY})
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 1)
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                return G.jokers.cards[1] == card
            end)() then
                card.ability.extra.Bitcoin = (card.ability.extra.Bitcoin) + 2
                return {
                    Xmult = 0.5
                }
            elseif (function()
                return G.jokers.cards[2] == card
            end)() then
                card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 2)
                return {
                    Xmult = 2
                }
            end
        end
        if context.skipping_booster  then
            return {
                func = function()
                    card.ability.extra.Bitcoin = (card.ability.extra.Bitcoin) + 1
                    return true
                end
            }
        end
        if context.setting_blind  then
            if (G.GAME.blind.boss and #G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_cryptowallet") then
                return {
                    func = function()
                        if G.GAME.blind and G.GAME.blind.boss and not G.GAME.blind.disabled then
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    G.GAME.blind:disable()
                                    play_sound('timpani')
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('ph_boss_disabled'), colour = G.C.GREEN})
                        end
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 1.5)
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            elseif (#G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_cryptowallet" and to_big((card.ability.extra.Bitcoin or 0)) >= to_big(0.5)) then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2).." Discards", colour = G.C.GREEN})
                        
                        G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + 2
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 0.5)
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
        if context.reroll_shop  then
            if not (#G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_cryptowallet") then
                return {
                    func = function()
                        card.ability.extra.Bitcoin = (card.ability.extra.Bitcoin) + 0.1
                        return true
                    end
                }
            elseif #G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_cryptowallet" then
                local target_hand = (context.scoring_name or "High Card")
                level_up_hand(card, target_hand, true, 1)
                return {
                    message = localize('k_level_up_ex')
                }
            end
        end
        if context.starting_shop  then
            if (#G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_cryptowallet" and to_big((card.ability.extra.Bitcoin or 0)) >= to_big(100)) then
                return {
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Joker Slot", colour = G.C.DARK_EDITION})
                        G.jokers.config.card_limit = G.jokers.config.card_limit + 1
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 100)
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
    end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_quantum_cryptowallet" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end

local can_select_card_ref = G.FUNCS.can_select_card
G.FUNCS.can_select_card = function(e)
    	if e.config.ref_table.config.center.key == "j_quantum_cryptowallet" then
        		e.config.colour = G.C.GREEN
        		e.config.button = "use_card"
    	else
        		can_select_card_ref(e)
    	end
end