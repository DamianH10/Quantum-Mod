
SMODS.Joker{ --Metallic Glass
    key = "metallicglass",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Metallic Glass',
        ['text'] = {
            [1] = 'Scored {C:attention}Steel{} or {C:attention}Gold{} Cards',
            [2] = 'are converted To {C:attention}Glass{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_misc"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_gold"] == true or SMODS.get_enhancements(context.other_card)["m_steel"] == true) then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        scored_card:set_ability(G.P_CENTERS.m_glass)
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.ORANGE})
                        return true
                    end
                }))
            end
        end
    end
}