
SMODS.Consumable {
    key = 'phi',
    set = '_subatomic_particle',
    pos = { x = 5, y = 1 },
    config = { 
        extra = {
            booster_slots0 = 1   
        } 
    },
    loc_txt = {
        name = 'Phi',
        text = {
            [1] = 'when used gives an extra',
            [2] = 'slot for booster pack.'
        }
    },
    cost = 8,
    unlocked = true,
    discovered = false,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
                card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Booster Slots", colour = G.C.BLUE})
                
                SMODS.change_booster_limit(1)
                return true
            end
        }))
        delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}