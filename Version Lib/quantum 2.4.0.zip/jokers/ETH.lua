
SMODS.Joker{ --Etherium
    key = "ETH",
    config = {
        extra = {
            blind_reward0_min = NaN,
            blind_reward0_max = 15
        }
    },
    loc_txt = {
        ['name'] = 'Etherium',
        ['text'] = {
            [1] = 'Gives between 15$ and {}-10$',
            [2] = 'at the end of a round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quant_jokers"] = true, ["quantum_util"] = true, ["quantum_misc"] = true }, 
    
    calc_dollar_bonus = function(card)
        local blind_reward = 0
        blind_reward = blind_reward + math.max(pseudorandom('RANGE:-10|15', -10, 15), 0)
        if blind_reward > 0 then
            return blind_reward
        end
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
        end
    end
}