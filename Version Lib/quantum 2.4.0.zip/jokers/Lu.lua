
SMODS.Joker{ --Lutetium
    key = "Lu",
    config = {
        extra = {
            money = 0
        }
    },
    loc_txt = {
        ['name'] = 'Lutetium',
        ['text'] = {
            [1] = 'Adds {C:money}2${} to the payout',
            [2] = 'for each card added.',
            [3] = 'Current {C:money}${}: {X:money,C:white}#1#{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_element"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.money}}
    end, 
    
    calc_dollar_bonus = function(card)
        local blind_reward = 0
        blind_reward = blind_reward + math.max(card.config.extra.money, 0)
        if blind_reward > 0 then
            return blind_reward
        end
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
        end
        if context.playing_card_added  then
            return {
                func = function()
                    card.ability.extra.money = (card.ability.extra.money) + 2
                    return true
                end
            }
        end
    end
}