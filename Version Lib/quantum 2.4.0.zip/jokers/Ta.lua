
SMODS.Joker{ --Tantalum
    key = "Ta",
    config = {
        extra = {
            Luck = 0
        }
    },
    loc_txt = {
        ['name'] = 'Tantalum',
        ['text'] = {
            [1] = 'adds {C:green}#1#{} to all odds.',
            [2] = 'Increases by 1',
            [3] = 'for each boss beat.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_element"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Luck}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            return {
                func = function()
                    card.ability.extra.Luck = (card.ability.extra.Luck) + 1
                    return true
                end
            }
        end
        if context.mod_probability  then
            local numerator, denominator = context.numerator, context.denominator
            numerator = numerator + (card.ability.extra.Luck)
            return {
                numerator = numerator, 
                denominator = denominator
            }
        end
    end
}