
SMODS.Joker{ --Axion
    key = "axion",
    config = {
        extra = {
            pb_bonus_809b5886 = 1000
        }
    },
    loc_txt = {
        ['name'] = 'Axion',
        ['text'] = {
            [1] = 'one of the canidates for Dark',
            [2] = 'Matter! Only interacts with',
            [3] = 'non face cards, adding',
            [4] = '{C:blue}1000{} permanent Chips.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = "quantum_mythic",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quant_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if not (context.other_card:is_face()) then
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + 1000
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card
                }
            end
        end
    end
}