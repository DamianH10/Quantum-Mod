
SMODS.Joker{ --Crypto wallet
    key = "cryptowallet",
    config = {
        extra = {
            Bitcoin = 0,
            Level = 0,
            dollars0 = 5,
            xmult0 = 0.5,
            xmult = 2,
            xmult2 = 0.25,
            xmult3 = 4,
            discards0 = 2,
            levels0 = 1,
            joker_slots0 = 1,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Crypto wallet',
        ['text'] = {
            [1] = '{C:red}SPECIAL CARD!{} Adds Cryptocurrency.',
            [2] = 'Current {C:hearts}B:{} {C:hearts} #1# {}{C:white}....{} Level: {C:dark_edition} #2# {}',
            [3] = 'Move to the very left to activate special abilities (or SA for short).',
            [4] = 'Do anything at 0.5X speed for Lv 1 and 1X to reset to 0. Functions:',
            [5] = '1. if bitcoin is present gain {C:hearts}1 B{} very round',
            [6] = '2. SA for buying a card: {C:hearts}-1B{} and get {C:money}5${} back',
            [7] = '3. SA when hand is played: {C:red}0.5X Mult{} {C:hearts}+2 B{}, if Lv 1 {C:red}0.25X{} {C:hearts}+5 B{}',
            [8] = '4. When placed in second slot: {C:red}2X Mult{} {C:hearts}-2 B{}, if Lv 1 {C:red}4X{} {C:hearts}-5 B{}',
            [9] = '5. When a Booster pack is skipped {C:hearts}+1 B{}, if Lv 1: {C:hearts}-1 B{}  {C:attention}+2{} tags',
            [10] = '6. When in boss blind and Lv 1, then disable it (for {C:hearts}1.5 B{})',
            [11] = '7. When entering a blind and Lv 1, gain {C:red}+2 Discards{} {C:hearts}-0.5 B{}',
            [12] = '8. On Reroll {C:hearts}+0.1 B{} or if Lv 1 level up the last played hand, {C:hearts}-1 B{}',
            [13] = '9. If Lv 1 and entring a shop: {C:hearts}-100 B{} {C:dark_edition}+ 1 Joker Slot{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_special"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Bitcoin, card.ability.extra.Level, card.ability.extra.var1}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_Bitcoin" then 
                        return true
                    end
                end
            end)() then
                return {
                    func = function()
                        card.ability.extra.Bitcoin = (card.ability.extra.Bitcoin) + 1
                        return true
                    end
                }
            end
        end
        if context.buying_card  and not context.blueprint then
            if ((function()
                return G.jokers.cards[1] == card
            end)() and to_big((card.ability.extra.Bitcoin or 0)) >= to_big(1)) then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 5
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(5), colour = G.C.MONEY})
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 1)
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if ((function()
                return G.jokers.cards[1] == card
            end)() and to_big((card.ability.extra.Level or 0)) == to_big(0)) then
                card.ability.extra.Bitcoin = (card.ability.extra.Bitcoin) + 2
                return {
                    Xmult = 0.5
                }
            elseif ((function()
                return G.jokers.cards[2] == card
            end)() and to_big((card.ability.extra.Bitcoin or 0)) >= to_big(2) and to_big((card.ability.extra.Level or 0)) == to_big(0)) then
                card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 2)
                return {
                    Xmult = 2
                }
            elseif ((function()
                return G.jokers.cards[1] == card
            end)() and to_big((card.ability.extra.Level or 0)) == to_big(1)) then
                card.ability.extra.Bitcoin = (card.ability.extra.Bitcoin) + 5
                return {
                    Xmult = 0.25
                }
            elseif ((function()
                return G.jokers.cards[2] == card
            end)() and to_big((card.ability.extra.var1 or 0)) >= to_big(5) and to_big((card.ability.extra.Level or 0)) == to_big(1)) then
                card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 5)
                return {
                    Xmult = 4
                }
            end
        end
        if context.skipping_booster  and not context.blueprint then
            if (to_big((card.ability.extra.Bitcoin or 0)) >= to_big(1) and to_big((card.ability.extra.Level or 0)) == to_big(1)) then
                return {
                    func = function()
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                local tag = Tag(selected_tag)
                                if tag.name == "Orbital Tag" then
                                    local _poker_hands = {}
                                    for k, v in pairs(G.GAME.hands) do
                                        if v.visible then
                                            _poker_hands[#_poker_hands + 1] = k
                                        end
                                    end
                                    tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                end
                                tag:set_ability()
                                add_tag(tag)
                                play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                return true
                            end
                        }))
                        return true
                    end,
                    message = "Created Tag!",
                    extra = {
                        func = function()
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                    local tag = Tag(selected_tag)
                                    if tag.name == "Orbital Tag" then
                                        local _poker_hands = {}
                                        for k, v in pairs(G.GAME.hands) do
                                            if v.visible then
                                                _poker_hands[#_poker_hands + 1] = k
                                            end
                                        end
                                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                    end
                                    tag:set_ability()
                                    add_tag(tag)
                                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                    return true
                                end
                            }))
                            return true
                        end,
                        message = "Created Tag!",
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                                card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 1)
                                return true
                            end,
                            colour = G.C.RED
                        }
                    }
                }
            else
                return {
                    func = function()
                        card.ability.extra.Bitcoin = (card.ability.extra.Bitcoin) + 1
                        return true
                    end
                }
            end
        end
        if context.setting_blind  and not context.blueprint then
            if (G.GAME.blind.boss and to_big((card.ability.extra.Level or 0)) == to_big(1)) then
                return {
                    func = function()
                        if G.GAME.blind and G.GAME.blind.boss and not G.GAME.blind.disabled then
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    G.GAME.blind:disable()
                                    play_sound('timpani')
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('ph_boss_disabled'), colour = G.C.GREEN})
                        end
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 1.5)
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            elseif (to_big((card.ability.extra.Bitcoin or 0)) >= to_big(0.5) and to_big((card.ability.extra.Level or 0)) == to_big(1)) then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2).." Discards", colour = G.C.GREEN})
                        
                        G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + 2
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 0.5)
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
        if context.reroll_shop  and not context.blueprint then
            if to_big((card.ability.extra.Level or 0)) == to_big(0) then
                return {
                    func = function()
                        card.ability.extra.Bitcoin = (card.ability.extra.Bitcoin) + 0.1
                        return true
                    end
                }
            elseif (to_big((card.ability.extra.Level or 0)) == to_big(1) and to_big((card.ability.extra.Bitcoin or 0)) >= to_big(1)) then
                local target_hand = (context.scoring_name or "High Card")
                level_up_hand(card, target_hand, true, 1)
                return {
                    message = localize('k_level_up_ex'),
                    extra = {
                        func = function()
                            card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 1)
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
        if context.starting_shop  and not context.blueprint then
            if (to_big((card.ability.extra.Bitcoin or 0)) >= to_big(100) and to_big((card.ability.extra.Level or 0)) == to_big(1)) then
                return {
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Joker Slot", colour = G.C.DARK_EDITION})
                        G.jokers.config.card_limit = G.jokers.config.card_limit + 1
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.Bitcoin = math.max(0, (card.ability.extra.Bitcoin) - 100)
                            return true
                        end,
                        colour = G.C.RED
                    }
                }
            end
        end
        if (context.end_of_round or context.reroll_shop or context.buying_card or
            context.selling_card or context.ending_shop or context.starting_shop or 
            context.ending_booster or context.skipping_booster or context.open_booster or
            context.skip_blind or context.before or context.pre_discard or context.setting_blind or
        context.using_consumeable)  and not context.blueprint  then
            if (to_big(G.SETTINGS.GAMESPEED) == to_big(0.5) and to_big((card.ability.extra.var1 or 0)) == to_big(0)) then
                return {
                    func = function()
                        card.ability.extra.Level = 1
                        return true
                    end
                }
            elseif (to_big(G.SETTINGS.GAMESPEED) == to_big(1) and to_big((card.ability.extra.Level or 0)) == to_big(1)) then
                return {
                    func = function()
                        card.ability.extra.Level = 0
                        return true
                    end
                }
            end
        end
    end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_quantum_cryptowallet" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end

local can_select_card_ref = G.FUNCS.can_select_card
G.FUNCS.can_select_card = function(e)
    	if e.config.ref_table.config.center.key == "j_quantum_cryptowallet" then
        		e.config.colour = G.C.GREEN
        		e.config.button = "use_card"
    	else
        		can_select_card_ref(e)
    	end
end