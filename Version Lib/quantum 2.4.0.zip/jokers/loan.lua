
SMODS.Joker{ --Loan
    key = "loan",
    config = {
        extra = {
            TrueFalse = 1,
            hands0 = 2,
            hands = 1
        }
    },
    loc_txt = {
        ['name'] = 'Loan',
        ['text'] = {
            [1] = 'changes between {C:blue}+2 Hands{}',
            [2] = 'and {C:red}-1 Hand{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quant_jokers"] = true, ["quantum_misc"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.TrueFalse}}
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if to_big((card.ability.extra.TrueFalse or 0)) == to_big(1) then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2).." Hands", colour = G.C.GREEN})
                        
                        G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + 2
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.TrueFalse = 0
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            elseif to_big((card.ability.extra.TrueFalse or 0)) == to_big(0) then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(1).." Hands", colour = G.C.RED})
                        G.GAME.current_round.hands_left = G.GAME.current_round.hands_left - 1
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.TrueFalse = 1
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            end
        end
    end
}