
SMODS.Joker{ --Time Dilation
    key = "timedilation",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Time Dilation',
        ['text'] = {
            [1] = 'Apply relative seal to the first played card.',
            [2] = 'time dilation works like this: you always move',
            [3] = 'through spacetime at lightspeed, now if you',
            [4] = 'stand perfectly still, you move through time',
            [5] = 'at lightspeed, if move at lightspeed through',
            [6] = 'space, you stand still in time, that\'s how speed',
            [7] = 'influences the passage of time (kinda).'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_misc"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[1] then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        scored_card:set_seal("quantum_relative", true)
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.ORANGE})
                        return true
                    end
                }))
            end
        end
    end
}