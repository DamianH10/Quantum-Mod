SMODS.ConsumableType {
    key = '_subatomic_particle',
    primary_colour = HEX('1d9a76'),
    secondary_colour = HEX('1d9a76'),
    collection_rows = { 4, 5 },
    shop_rate = 0.5,
    cards = {
        ['c_quantum_Lambda'] = true,
        ['c_quantum_Delta Baryon'] = true,
        ['c_quantum_dmeson'] = true,
        ['c_quantum_kaon'] = true,
        ['c_quantum_Omega Baryon'] = true,
        ['c_quantum_pion'] = true,
        ['c_quantum_Xi Baryon'] = true,
        ['c_quantum_rho'] = true,
        ['c_quantum_phi'] = true,
        ['c_quantum_omegameson'] = true,
        ['c_quantum_eta'] = true,
        ['c_quantum_Upsilon'] = true,
        ['c_quantum_thetameson'] = true,
        ['c_quantum_psimeson'] = true,
        ['c_quantum_sigmabaryon'] = true,
        ['c_quantum_tmeson'] = true,
        ['c_quantum_bmeson'] = true
    },
    loc_txt = {
        name = " Subatomic Particle",
        collection = " Subatomic Particle Cards",
    }
}

SMODS.ConsumableType {
    key = 'chemical',
    primary_colour = HEX('000692'),
    secondary_colour = HEX('000692'),
    collection_rows = { 4, 5 },
    shop_rate = 1.1,
    cards = {
        ['c_quantum_N6'] = true,
        ['c_quantum_ozone'] = true,
        ['c_quantum_buckminsterfullerene'] = true,
        ['c_quantum_flouroantimonicacid'] = true,
        ['c_quantum_f2'] = true,
        ['c_quantum_COCl2'] = true,
        ['c_quantum_dimethylmercury'] = true
    },
    loc_txt = {
        name = "Chemical",
        collection = "Chemical Cards",
    }
}

SMODS.ConsumableType {
    key = 'isotope',
    primary_colour = HEX('417505'),
    secondary_colour = HEX('417505'),
    collection_rows = { 4, 5 },
    shop_rate = 0.8,
    cards = {
        ['c_quantum_carbon12metastable'] = true
    },
    loc_txt = {
        name = "Isotope",
        collection = "Isotope Cards",
    }
}