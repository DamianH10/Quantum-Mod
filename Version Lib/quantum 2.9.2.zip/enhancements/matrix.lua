
SMODS.Enhancement {
    key = 'matrix',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            xchips0 = 2,
            mult0 = 5
        }
    },
    loc_txt = {
        name = 'Matrix',
        text = {
            [1] = '{C:green}you can take the{} {C:blue}Blue Pill{} {C:green}and stay on windows{}',
            [2] = '{C:green}loosing out on xchips and having ai slop{} {C:dark_edition}OR{}',
            [3] = '{C:uncommon}take the{} {C:red}Red Pill{} {C:uncommon}go to {}{C:dark_edition}Linux{} {C:uncommon} and see how little{}',
            [4] = '{C:uncommon}ai slop and spyware there is, and {}{C:blue}x1.75 Chips{}'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = false,
    no_collection = false,
    weight = 3.5,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play and love.system.getOS() == "Linux" then
            return {
                x_chips = 2,
                extra = {
                    mult = 5
                }
            }
        end
    end
}