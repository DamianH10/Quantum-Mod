
SMODS.Joker{ --Chromium
    key = "Cr",
    config = {
        extra = {
            chips0 = 25
        }
    },
    loc_txt = {
        ['name'] = 'Chromium',
        ['text'] = {
            [1] = 'All odd cards held',
            [2] = 'in hand give {C:blue}+25{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quant_jokers"] = true, ["quantum_element"] = true, ["quantum_metal"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if (context.other_card:get_id() == 14 or context.other_card:get_id() == 3 or context.other_card:get_id() == 5 or context.other_card:get_id() == 7 or context.other_card:get_id() == 9) then
                return {
                    chips = 25
                }
            end
        end
    end
}