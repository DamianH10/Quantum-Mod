
SMODS.Joker{ --Rhenium
    key = "Re",
    config = {
        extra = {
            repetitions0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Rhenium',
        ['text'] = {
            [1] = 'Retrigger the first card held',
            [2] = 'in hand {C:attention}4{} times.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_metal"] = true, ["quantum_element"] = true },
    
    calculate = function(self, card, context)
        if context.repetition and not context.cardarea == G.hand and context.end_of_round and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            if context.other_card == context.scoring_hand[1] then
                return {
                    repetitions = 4,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}