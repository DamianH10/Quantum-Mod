
SMODS.Joker{ --Tungsten
    key = "W",
    config = {
        extra = {
            xmult0 = 1.75
        }
    },
    loc_txt = {
        ['name'] = 'Tungsten',
        ['text'] = {
            [1] = 'Non Face cards held in hand give {X:red,C:white}×1.75{} {C:red}Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_element"] = true, ["quantum_metal"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if not (context.other_card:is_face()) then
                return {
                    Xmult = 1.75
                }
            end
        end
    end
}