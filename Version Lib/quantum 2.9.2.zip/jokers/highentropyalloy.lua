
SMODS.Joker{ --High entropy Alloy
    key = "highentropyalloy",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'High entropy Alloy',
        ['text'] = {
            [1] = 'Copies the joker to the left and right.',
            [2] = 'High enrtopy alloys (HEAs) are a type of',
            [3] = 'alloy, that contrary to normal alloys does',
            [4] = 'not have a base element, and is instead',
            [5] = 'a certain combination of roughly equal',
            [6] = 'parts. Certain combinations yield a',
            [7] = 'perfectly distributed alloy, which can have',
            [8] = 'unique properties.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "quantum_ultra_rare",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_metal"] = true },
    
    calculate = function(self, card, context)
        
        local target_joker = nil
        
        local my_pos = nil
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i] == card then
                my_pos = i
                break
            end
        end
        target_joker = (my_pos and my_pos > 1) and G.jokers.cards[my_pos - 1] or nil
        
        local ret = SMODS.blueprint_effect(card, target_joker, context)
        if ret then
            SMODS.calculate_effect(ret, card)
        end
        
        local target_joker = nil
        
        local my_pos = nil
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i] == card then
                my_pos = i
                break
            end
        end
        target_joker = (my_pos and my_pos < #G.jokers.cards) and G.jokers.cards[my_pos + 1] or nil
        
        local ret = SMODS.blueprint_effect(card, target_joker, context)
        if ret then
            SMODS.calculate_effect(ret, card)
        end
    end
}