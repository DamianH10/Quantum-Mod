
SMODS.Joker{ --Pay to Win
    key = "paytowin",
    config = {
        extra = {
            mult = 1,
            dollars0 = 6,
            dollars = 6
        }
    },
    loc_txt = {
        ['name'] = 'Pay to Win',
        ['text'] = {
            [1] = 'When Buying a card or selling a card',
            [2] = 'Pay {C:money}6${} extra, if this cards is the',
            [3] = 'rightmost card, then Gain + {X:red,C:white}0.25{} {C:red}XMult.{}',
            [4] = 'Current Mult:  {X:red,C:white}×#1#{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 15,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_misc"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.mult}}
    end,
    
    calculate = function(self, card, context)
        if context.selling_card  then
            if (function()
                return G.jokers.cards[#G.jokers.cards] == card
            end)() then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars - 6
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(6), colour = G.C.MONEY})
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.mult = (card.ability.extra.mult) + 0.25
                            return true
                        end,
                        colour = G.C.GREEN
                    }
                }
            end
        end
        if context.buying_card  then
            if (function()
                return G.jokers.cards[#G.jokers.cards] == card
            end)() then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars - 6
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(6), colour = G.C.MONEY})
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.mult = (card.ability.extra.mult) + 0.25
                            return true
                        end,
                        colour = G.C.GREEN
                    }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.mult
            }
        end
    end
}