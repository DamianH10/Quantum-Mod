
SMODS.Joker{ --Savings
    key = "savings",
    config = {
        extra = {
            currentmoney = 0
        }
    },
    loc_txt = {
        ['name'] = 'Savings',
        ['text'] = {
            [1] = 'scored cards give {C:blue}chips{} equal',
            [2] = 'to {C:money}money{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_misc"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(G.GAME.dollars or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                chips = G.GAME.dollars
            }
        end
    end
}