
SMODS.Joker{ --W.I.P
    key = "wip",
    config = {
        extra = {
            effect = 0,
            currentmoney = 0,
            cardsindeck = 0,
            xchips0 = 3,
            xmult0 = 3,
            xchips = 10,
            xchips2 = 2.5,
            xchips3 = 2,
            xchips4 = 1.5,
            xmult = 1.5,
            xchips5 = 1.75,
            chips = 50,
            dollars0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'W.I.P',
        ['text'] = {
            [1] = 'Joker not finished yet,',
            [2] = 'so Work in progress!',
            [3] = '{C:grey}Or is it?{}',
            [4] = '{C:grey}current effect: #1#{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_misc"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.effect, (G.GAME.dollars or 0), (#(G.deck and G.deck.cards or {}) or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()
                    card.ability.extra.effect = pseudorandom('RANGE:1|12', 1, 12)
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big((card.ability.extra.effect or 0)) == to_big(1) then
                return {
                    x_chips = 3,
                    extra = {
                        Xmult = 3
                    }
                }
            elseif (next(context.poker_hands["Five of a Kind"]) and to_big((card.ability.extra.effect or 0)) == to_big(8)) then
                return {
                    x_chips = 10
                }
            elseif to_big((card.ability.extra.effect or 0)) == to_big(12) then
                return {
                    balance = true
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if ((function()
                local enhancements = SMODS.get_enhancements(context.other_card)
                for k, v in pairs(enhancements) do
                    if v then
                        return true
                    end
                end
                return false
            end)() and to_big((card.ability.extra.effect or 0)) == to_big(2)) then
                return {
                    x_chips = 2.5
                }
            elseif (not (context.other_card:is_face()) and to_big((card.ability.extra.effect or 0)) == to_big(3)) then
                return {
                    x_chips = 2
                }
            elseif ((context.other_card:get_id() == 14 or context.other_card:get_id() == 3 or context.other_card:get_id() == 5 or context.other_card:get_id() == 7 or context.other_card:get_id() == 9) and to_big((card.ability.extra.effect or 0)) == to_big(4)) then
                return {
                    x_chips = 1.5
                }
            elseif ((context.other_card:get_id() == 2 or context.other_card:get_id() == 4 or context.other_card:get_id() == 6 or context.other_card:get_id() == 8 or context.other_card:get_id() == 10) and to_big((card.ability.extra.effect or 0)) == to_big(5)) then
                return {
                    Xmult = 1.5
                }
            elseif (context.other_card.seal ~= nil and to_big((card.ability.extra.effect or 0)) == to_big(6)) then
                return {
                    x_chips = 1.75
                }
            elseif to_big((card.ability.extra.effect or 0)) == to_big(9) then
                return {
                    chips = G.GAME.dollars
                }
            elseif to_big((card.ability.extra.effect or 0)) == to_big(10) then
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + #(G.deck and G.deck.cards or {})
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card
                }
            end
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if to_big((card.ability.extra.effect or 0)) == to_big(7) then
                return {
                    chips = 50
                }
            end
        end
        if context.other_joker  then
            if to_big((card.ability.extra.effect or 0)) == to_big(11) then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars + 1
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
    end
}