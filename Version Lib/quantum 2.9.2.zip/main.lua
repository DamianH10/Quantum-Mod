SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomConsumables", 
    path = "CustomConsumables.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomEnhancements", 
    path = "CustomEnhancements.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomSeals", 
    path = "CustomSeals.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
}):register()

SMODS.Atlas({
    key = "CustomVouchers", 
    path = "CustomVouchers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end
-- this function is used to load everything within a folder.-- Jokerforge doesnt use it because it doesnt make loading order easy
local function load_folder(path)
    local files = NFS.getDirectoryItemsInfo(mod_path .. "/" .. path)
    for i = 1, #files do
        local file_name = files[i].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file(path .. file_name))()
        end
    end
end
-- load the jokers
if true then
    assert(SMODS.load_file("jokers/C.lua"))()
    assert(SMODS.load_file("jokers/H.lua"))()
    assert(SMODS.load_file("jokers/He.lua"))()
    assert(SMODS.load_file("jokers/Li.lua"))()
    assert(SMODS.load_file("jokers/Be.lua"))()
    assert(SMODS.load_file("jokers/B.lua"))()
    assert(SMODS.load_file("jokers/N.lua"))()
    assert(SMODS.load_file("jokers/O.lua"))()
    assert(SMODS.load_file("jokers/F.lua"))()
    assert(SMODS.load_file("jokers/Ne.lua"))()
    assert(SMODS.load_file("jokers/TBL.lua"))()
    assert(SMODS.load_file("jokers/FP.lua"))()
    assert(SMODS.load_file("jokers/Bitcoin.lua"))()
    assert(SMODS.load_file("jokers/ETH.lua"))()
    assert(SMODS.load_file("jokers/QuantumEntanglement.lua"))()
    assert(SMODS.load_file("jokers/FractalGeometry.lua"))()
    assert(SMODS.load_file("jokers/NeutronStar.lua"))()
    assert(SMODS.load_file("jokers/Weak.lua"))()
    assert(SMODS.load_file("jokers/MTO.lua"))()
    assert(SMODS.load_file("jokers/reportcard.lua"))()
    assert(SMODS.load_file("jokers/BlackHole.lua"))()
    assert(SMODS.load_file("jokers/DyingStar.lua"))()
    assert(SMODS.load_file("jokers/SupermassiveStar.lua"))()
    assert(SMODS.load_file("jokers/star.lua"))()
    assert(SMODS.load_file("jokers/DownQuark.lua"))()
    assert(SMODS.load_file("jokers/UpQuark.lua"))()
    assert(SMODS.load_file("jokers/StrangeQuark.lua"))()
    assert(SMODS.load_file("jokers/CharmQuark.lua"))()
    assert(SMODS.load_file("jokers/BottomQuark.lua"))()
    assert(SMODS.load_file("jokers/TopQuark.lua"))()
    assert(SMODS.load_file("jokers/electron.lua"))()
    assert(SMODS.load_file("jokers/muon.lua"))()
    assert(SMODS.load_file("jokers/tau.lua"))()
    assert(SMODS.load_file("jokers/pentaquark.lua"))()
    assert(SMODS.load_file("jokers/gravity.lua"))()
    assert(SMODS.load_file("jokers/higgs.lua"))()
    assert(SMODS.load_file("jokers/electromagnetism.lua"))()
    assert(SMODS.load_file("jokers/zboson.lua"))()
    assert(SMODS.load_file("jokers/wboson.lua"))()
    assert(SMODS.load_file("jokers/wboson2.lua"))()
    assert(SMODS.load_file("jokers/photon.lua"))()
    assert(SMODS.load_file("jokers/gluon.lua"))()
    assert(SMODS.load_file("jokers/Na.lua"))()
    assert(SMODS.load_file("jokers/Mg.lua"))()
    assert(SMODS.load_file("jokers/Al.lua"))()
    assert(SMODS.load_file("jokers/Si.lua"))()
    assert(SMODS.load_file("jokers/P.lua"))()
    assert(SMODS.load_file("jokers/omiverse.lua"))()
    assert(SMODS.load_file("jokers/tachyon.lua"))()
    assert(SMODS.load_file("jokers/S.lua"))()
    assert(SMODS.load_file("jokers/Cl.lua"))()
    assert(SMODS.load_file("jokers/Ar.lua"))()
    assert(SMODS.load_file("jokers/stringtheory.lua"))()
    assert(SMODS.load_file("jokers/axion.lua"))()
    assert(SMODS.load_file("jokers/graviton.lua"))()
    assert(SMODS.load_file("jokers/xboson.lua"))()
    assert(SMODS.load_file("jokers/yboson.lua"))()
    assert(SMODS.load_file("jokers/omgparticle.lua"))()
    assert(SMODS.load_file("jokers/solidstate.lua"))()
    assert(SMODS.load_file("jokers/liquidstate.lua"))()
    assert(SMODS.load_file("jokers/gaseousstate.lua"))()
    assert(SMODS.load_file("jokers/plasma.lua"))()
    assert(SMODS.load_file("jokers/superfluidity.lua"))()
    assert(SMODS.load_file("jokers/K.lua"))()
    assert(SMODS.load_file("jokers/Ca.lua"))()
    assert(SMODS.load_file("jokers/Sc.lua"))()
    assert(SMODS.load_file("jokers/67.lua"))()
    assert(SMODS.load_file("jokers/Cr.lua"))()
    assert(SMODS.load_file("jokers/meme.lua"))()
    assert(SMODS.load_file("jokers/Ti.lua"))()
    assert(SMODS.load_file("jokers/V.lua"))()
    assert(SMODS.load_file("jokers/Fe.lua"))()
    assert(SMODS.load_file("jokers/timecrystal.lua"))()
    assert(SMODS.load_file("jokers/boseeinsteincondensate.lua"))()
    assert(SMODS.load_file("jokers/sterileneutrino.lua"))()
    assert(SMODS.load_file("jokers/Co.lua"))()
    assert(SMODS.load_file("jokers/Ni.lua"))()
    assert(SMODS.load_file("jokers/Cu.lua"))()
    assert(SMODS.load_file("jokers/leptoquark.lua"))()
    assert(SMODS.load_file("jokers/Zn.lua"))()
    assert(SMODS.load_file("jokers/Ga.lua"))()
    assert(SMODS.load_file("jokers/Ge.lua"))()
    assert(SMODS.load_file("jokers/As.lua"))()
    assert(SMODS.load_file("jokers/Se.lua"))()
    assert(SMODS.load_file("jokers/bromine.lua"))()
    assert(SMODS.load_file("jokers/Kr.lua"))()
    assert(SMODS.load_file("jokers/electronneutrino.lua"))()
    assert(SMODS.load_file("jokers/muonneutrino.lua"))()
    assert(SMODS.load_file("jokers/tauneutrino.lua"))()
    assert(SMODS.load_file("jokers/Rb.lua"))()
    assert(SMODS.load_file("jokers/Sr.lua"))()
    assert(SMODS.load_file("jokers/Y.lua"))()
    assert(SMODS.load_file("jokers/Zr.lua"))()
    assert(SMODS.load_file("jokers/Nb.lua"))()
    assert(SMODS.load_file("jokers/Mo.lua"))()
    assert(SMODS.load_file("jokers/Tc.lua"))()
    assert(SMODS.load_file("jokers/Ru.lua"))()
    assert(SMODS.load_file("jokers/Pd.lua"))()
    assert(SMODS.load_file("jokers/cd.lua"))()
    assert(SMODS.load_file("jokers/In.lua"))()
    assert(SMODS.load_file("jokers/Sn.lua"))()
    assert(SMODS.load_file("jokers/Sb.lua"))()
    assert(SMODS.load_file("jokers/Te.lua"))()
    assert(SMODS.load_file("jokers/I.lua"))()
    assert(SMODS.load_file("jokers/Xe.lua"))()
    assert(SMODS.load_file("jokers/Cs.lua"))()
    assert(SMODS.load_file("jokers/Ba.lua"))()
    assert(SMODS.load_file("jokers/La.lua"))()
    assert(SMODS.load_file("jokers/Ce.lua"))()
    assert(SMODS.load_file("jokers/Pr.lua"))()
    assert(SMODS.load_file("jokers/Nd.lua"))()
    assert(SMODS.load_file("jokers/Pm.lua"))()
    assert(SMODS.load_file("jokers/Sm.lua"))()
    assert(SMODS.load_file("jokers/Eu.lua"))()
    assert(SMODS.load_file("jokers/Gd.lua"))()
    assert(SMODS.load_file("jokers/Tb.lua"))()
    assert(SMODS.load_file("jokers/Dy.lua"))()
    assert(SMODS.load_file("jokers/GUT.lua"))()
    assert(SMODS.load_file("jokers/cosmon.lua"))()
    assert(SMODS.load_file("jokers/glueball.lua"))()
    assert(SMODS.load_file("jokers/phonon.lua"))()
    assert(SMODS.load_file("jokers/majoranaparticle.lua"))()
    assert(SMODS.load_file("jokers/electronhole.lua"))()
    assert(SMODS.load_file("jokers/anyon.lua"))()
    assert(SMODS.load_file("jokers/Ho.lua"))()
    assert(SMODS.load_file("jokers/Er.lua"))()
    assert(SMODS.load_file("jokers/Tm.lua"))()
    assert(SMODS.load_file("jokers/taxreturns.lua"))()
    assert(SMODS.load_file("jokers/loan.lua"))()
    assert(SMODS.load_file("jokers/ytterbium.lua"))()
    assert(SMODS.load_file("jokers/glassshards.lua"))()
    assert(SMODS.load_file("jokers/metallicglass.lua"))()
    assert(SMODS.load_file("jokers/cryptowallet.lua"))()
    assert(SMODS.load_file("jokers/Lu.lua"))()
    assert(SMODS.load_file("jokers/Hf.lua"))()
    assert(SMODS.load_file("jokers/Ta.lua"))()
    assert(SMODS.load_file("jokers/paytowin.lua"))()
    assert(SMODS.load_file("jokers/wip.lua"))()
    assert(SMODS.load_file("jokers/savings.lua"))()
    assert(SMODS.load_file("jokers/timedilation.lua"))()
    assert(SMODS.load_file("jokers/thematrix.lua"))()
    assert(SMODS.load_file("jokers/highentropyalloy.lua"))()
    assert(SMODS.load_file("jokers/W.lua"))()
    assert(SMODS.load_file("jokers/Re.lua"))()
end
-- load the consumables
if true then
    assert(SMODS.load_file("consumables/N6.lua"))()
    assert(SMODS.load_file("consumables/Lambda.lua"))()
    assert(SMODS.load_file("consumables/Delta Baryon.lua"))()
    assert(SMODS.load_file("consumables/dmeson.lua"))()
    assert(SMODS.load_file("consumables/kaon.lua"))()
    assert(SMODS.load_file("consumables/Omega Baryon.lua"))()
    assert(SMODS.load_file("consumables/pion.lua"))()
    assert(SMODS.load_file("consumables/Xi Baryon.lua"))()
    assert(SMODS.load_file("consumables/ozone.lua"))()
    assert(SMODS.load_file("consumables/carbon12metastable.lua"))()
    assert(SMODS.load_file("consumables/buckminsterfullerene.lua"))()
    assert(SMODS.load_file("consumables/flouroantimonicacid.lua"))()
    assert(SMODS.load_file("consumables/f2.lua"))()
    assert(SMODS.load_file("consumables/COCl2.lua"))()
    assert(SMODS.load_file("consumables/rho.lua"))()
    assert(SMODS.load_file("consumables/phi.lua"))()
    assert(SMODS.load_file("consumables/omegameson.lua"))()
    assert(SMODS.load_file("consumables/eta.lua"))()
    assert(SMODS.load_file("consumables/Upsilon.lua"))()
    assert(SMODS.load_file("consumables/thetameson.lua"))()
    assert(SMODS.load_file("consumables/psimeson.lua"))()
    assert(SMODS.load_file("consumables/sigmabaryon.lua"))()
    assert(SMODS.load_file("consumables/dimethylmercury.lua"))()
    assert(SMODS.load_file("consumables/tmeson.lua"))()
    assert(SMODS.load_file("consumables/bmeson.lua"))()
end
--load the sets
assert(SMODS.load_file("consumables/sets.lua"))()
-- load the enhancements
if true then
    assert(SMODS.load_file("enhancements/toxic.lua"))()
    assert(SMODS.load_file("enhancements/matrix.lua"))()
end

-- load the seals
if true then
    assert(SMODS.load_file("seals/entangled.lua"))()
    assert(SMODS.load_file("seals/re2.lua"))()
    assert(SMODS.load_file("seals/re3.lua"))()
    assert(SMODS.load_file("seals/re4.lua"))()
    assert(SMODS.load_file("seals/re5.lua"))()
    assert(SMODS.load_file("seals/re6.lua"))()
    assert(SMODS.load_file("seals/re7.lua"))()
    assert(SMODS.load_file("seals/re8.lua"))()
    assert(SMODS.load_file("seals/re9.lua"))()
    assert(SMODS.load_file("seals/re10.lua"))()
    assert(SMODS.load_file("seals/poisonedseal.lua"))()
    assert(SMODS.load_file("seals/relative.lua"))()
end

-- load the editions
if true then
    assert(SMODS.load_file("editions/irradiated.lua"))()
end

-- load the vouchers
if true then
    assert(SMODS.load_file("vouchers/rare_goods.lua"))()
    assert(SMODS.load_file("vouchers/exotic_goods.lua"))()
    assert(SMODS.load_file("vouchers/recycle.lua"))()
    assert(SMODS.load_file("vouchers/superrecycle.lua"))()
end

-- load the decks
if true then
    assert(SMODS.load_file("decks/element_deck.lua"))()
    assert(SMODS.load_file("decks/rarities_deck_.lua"))()
    assert(SMODS.load_file("decks/extremerarities_deck.lua"))()
    assert(SMODS.load_file("decks/blank.lua"))()
    assert(SMODS.load_file("decks/odyssey_deck.lua"))()
    assert(SMODS.load_file("decks/vantablack_deck.lua"))()
    assert(SMODS.load_file("decks/black_hole_deck.lua"))()
    assert(SMODS.load_file("decks/black_hole_deck_ultima.lua"))()
    assert(SMODS.load_file("decks/scale_deck_hs.lua"))()
    assert(SMODS.load_file("decks/balance_deck.lua"))()
    assert(SMODS.load_file("decks/scale_deck_js.lua"))()
    assert(SMODS.load_file("decks/crypto_deck.lua"))()
end



assert(SMODS.load_file("rarities.lua"))()


-- load boosters
assert(SMODS.load_file("boosters.lua"))()
SMODS.ObjectType({
    key = "quantum_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "quantum_element",
    cards = {
        ["j_quantum_C"] = true,
        ["j_quantum_H"] = true,
        ["j_quantum_He"] = true,
        ["j_quantum_Li"] = true,
        ["j_quantum_Be"] = true,
        ["j_quantum_B"] = true,
        ["j_quantum_N"] = true,
        ["j_quantum_O"] = true,
        ["j_quantum_F"] = true,
        ["j_quantum_Ne"] = true,
        ["j_quantum_Na"] = true,
        ["j_quantum_Mg"] = true,
        ["j_quantum_Al"] = true,
        ["j_quantum_Si"] = true,
        ["j_quantum_P"] = true,
        ["j_quantum_S"] = true,
        ["j_quantum_Cl"] = true,
        ["j_quantum_Ar"] = true,
        ["j_quantum_K"] = true,
        ["j_quantum_Ca"] = true,
        ["j_quantum_Sc"] = true,
        ["j_quantum_Cr"] = true,
        ["j_quantum_Ti"] = true,
        ["j_quantum_V"] = true,
        ["j_quantum_Fe"] = true,
        ["j_quantum_Co"] = true,
        ["j_quantum_Ni"] = true,
        ["j_quantum_Cu"] = true,
        ["j_quantum_Zn"] = true,
        ["j_quantum_Ge"] = true,
        ["j_quantum_As"] = true,
        ["j_quantum_Se"] = true,
        ["j_quantum_bromine"] = true,
        ["j_quantum_Kr"] = true,
        ["j_quantum_Rb"] = true,
        ["j_quantum_Sr"] = true,
        ["j_quantum_Y"] = true,
        ["j_quantum_Zr"] = true,
        ["j_quantum_Nb"] = true,
        ["j_quantum_Mo"] = true,
        ["j_quantum_Tc"] = true,
        ["j_quantum_Ru"] = true,
        ["j_quantum_Pd"] = true,
        ["j_quantum_cd"] = true,
        ["j_quantum_In"] = true,
        ["j_quantum_Sn"] = true,
        ["j_quantum_Sb"] = true,
        ["j_quantum_Te"] = true,
        ["j_quantum_I"] = true,
        ["j_quantum_Xe"] = true,
        ["j_quantum_Cs"] = true,
        ["j_quantum_Ba"] = true,
        ["j_quantum_La"] = true,
        ["j_quantum_Ce"] = true,
        ["j_quantum_Pr"] = true,
        ["j_quantum_Nd"] = true,
        ["j_quantum_Pm"] = true,
        ["j_quantum_Sm"] = true,
        ["j_quantum_Eu"] = true,
        ["j_quantum_Gd"] = true,
        ["j_quantum_Tb"] = true,
        ["j_quantum_Dy"] = true,
        ["j_quantum_Ho"] = true,
        ["j_quantum_Er"] = true,
        ["j_quantum_Tm"] = true,
        ["j_quantum_ytterbium"] = true,
        ["j_quantum_Lu"] = true,
        ["j_quantum_Hf"] = true,
        ["j_quantum_Ta"] = true,
        ["j_quantum_W"] = true,
        ["j_quantum_Re"] = true
    },
})

SMODS.ObjectType({
    key = "quantum_quant_jokers",
    cards = {
        ["j_quantum_C"] = true,
        ["j_quantum_H"] = true,
        ["j_quantum_He"] = true,
        ["j_quantum_Li"] = true,
        ["j_quantum_Be"] = true,
        ["j_quantum_B"] = true,
        ["j_quantum_N"] = true,
        ["j_quantum_O"] = true,
        ["j_quantum_F"] = true,
        ["j_quantum_Ne"] = true,
        ["j_quantum_TBL"] = true,
        ["j_quantum_FP"] = true,
        ["j_quantum_Bitcoin"] = true,
        ["j_quantum_ETH"] = true,
        ["j_quantum_QuantumEntanglement"] = true,
        ["j_quantum_FractalGeometry"] = true,
        ["j_quantum_NeutronStar"] = true,
        ["j_quantum_Weak"] = true,
        ["j_quantum_MTO"] = true,
        ["j_quantum_reportcard"] = true,
        ["j_quantum_BlackHole"] = true,
        ["j_quantum_DyingStar"] = true,
        ["j_quantum_SupermassiveStar"] = true,
        ["j_quantum_star"] = true,
        ["j_quantum_DownQuark"] = true,
        ["j_quantum_UpQuark"] = true,
        ["j_quantum_StrangeQuark"] = true,
        ["j_quantum_CharmQuark"] = true,
        ["j_quantum_BottomQuark"] = true,
        ["j_quantum_TopQuark"] = true,
        ["j_quantum_electron"] = true,
        ["j_quantum_muon"] = true,
        ["j_quantum_tau"] = true,
        ["j_quantum_pentaquark"] = true,
        ["j_quantum_gravity"] = true,
        ["j_quantum_higgs"] = true,
        ["j_quantum_electromagnetism"] = true,
        ["j_quantum_zboson"] = true,
        ["j_quantum_wboson"] = true,
        ["j_quantum_wboson2"] = true,
        ["j_quantum_photon"] = true,
        ["j_quantum_gluon"] = true,
        ["j_quantum_Na"] = true,
        ["j_quantum_Mg"] = true,
        ["j_quantum_Al"] = true,
        ["j_quantum_Si"] = true,
        ["j_quantum_P"] = true,
        ["j_quantum_omiverse"] = true,
        ["j_quantum_tachyon"] = true,
        ["j_quantum_S"] = true,
        ["j_quantum_Cl"] = true,
        ["j_quantum_Ar"] = true,
        ["j_quantum_stringtheory"] = true,
        ["j_quantum_axion"] = true,
        ["j_quantum_graviton"] = true,
        ["j_quantum_xboson"] = true,
        ["j_quantum_yboson"] = true,
        ["j_quantum_omgparticle"] = true,
        ["j_quantum_solidstate"] = true,
        ["j_quantum_liquidstate"] = true,
        ["j_quantum_gaseousstate"] = true,
        ["j_quantum_plasma"] = true,
        ["j_quantum_superfluidity"] = true,
        ["j_quantum_K"] = true,
        ["j_quantum_Ca"] = true,
        ["j_quantum_Sc"] = true,
        ["j_quantum_Cr"] = true,
        ["j_quantum_meme"] = true,
        ["j_quantum_Ti"] = true,
        ["j_quantum_V"] = true,
        ["j_quantum_Fe"] = true,
        ["j_quantum_timecrystal"] = true,
        ["j_quantum_boseeinsteincondensate"] = true,
        ["j_quantum_sterileneutrino"] = true,
        ["j_quantum_Co"] = true,
        ["j_quantum_Ni"] = true,
        ["j_quantum_Cu"] = true,
        ["j_quantum_leptoquark"] = true,
        ["j_quantum_Zn"] = true,
        ["j_quantum_Ga"] = true,
        ["j_quantum_Ge"] = true,
        ["j_quantum_As"] = true,
        ["j_quantum_Se"] = true,
        ["j_quantum_bromine"] = true,
        ["j_quantum_Kr"] = true,
        ["j_quantum_electronneutrino"] = true,
        ["j_quantum_muonneutrino"] = true,
        ["j_quantum_tauneutrino"] = true,
        ["j_quantum_Rb"] = true,
        ["j_quantum_Sr"] = true,
        ["j_quantum_Y"] = true,
        ["j_quantum_Zr"] = true,
        ["j_quantum_Nb"] = true,
        ["j_quantum_Mo"] = true,
        ["j_quantum_Tc"] = true,
        ["j_quantum_Ru"] = true,
        ["j_quantum_Pd"] = true,
        ["j_quantum_cd"] = true,
        ["j_quantum_In"] = true,
        ["j_quantum_Sn"] = true,
        ["j_quantum_Sb"] = true,
        ["j_quantum_Te"] = true,
        ["j_quantum_I"] = true,
        ["j_quantum_Xe"] = true,
        ["j_quantum_Cs"] = true,
        ["j_quantum_Ba"] = true,
        ["j_quantum_La"] = true,
        ["j_quantum_Ce"] = true,
        ["j_quantum_Pr"] = true,
        ["j_quantum_Nd"] = true,
        ["j_quantum_Pm"] = true,
        ["j_quantum_Sm"] = true,
        ["j_quantum_Eu"] = true,
        ["j_quantum_Gd"] = true,
        ["j_quantum_Tb"] = true,
        ["j_quantum_Dy"] = true,
        ["j_quantum_GUT"] = true,
        ["j_quantum_cosmon"] = true,
        ["j_quantum_glueball"] = true,
        ["j_quantum_phonon"] = true,
        ["j_quantum_majoranaparticle"] = true,
        ["j_quantum_electronhole"] = true,
        ["j_quantum_anyon"] = true,
        ["j_quantum_Ho"] = true,
        ["j_quantum_Er"] = true,
        ["j_quantum_Tm"] = true,
        ["j_quantum_taxreturns"] = true,
        ["j_quantum_loan"] = true,
        ["j_quantum_ytterbium"] = true
    },
})

SMODS.ObjectType({
    key = "quantum_metal",
    cards = {
        ["j_quantum_Li"] = true,
        ["j_quantum_Be"] = true,
        ["j_quantum_Na"] = true,
        ["j_quantum_Mg"] = true,
        ["j_quantum_Al"] = true,
        ["j_quantum_K"] = true,
        ["j_quantum_Ca"] = true,
        ["j_quantum_Sc"] = true,
        ["j_quantum_Cr"] = true,
        ["j_quantum_Ti"] = true,
        ["j_quantum_V"] = true,
        ["j_quantum_Fe"] = true,
        ["j_quantum_Co"] = true,
        ["j_quantum_Ni"] = true,
        ["j_quantum_Cu"] = true,
        ["j_quantum_Zn"] = true,
        ["j_quantum_Ga"] = true,
        ["j_quantum_Rb"] = true,
        ["j_quantum_Sr"] = true,
        ["j_quantum_Y"] = true,
        ["j_quantum_Zr"] = true,
        ["j_quantum_Nb"] = true,
        ["j_quantum_Mo"] = true,
        ["j_quantum_Tc"] = true,
        ["j_quantum_Ru"] = true,
        ["j_quantum_Pd"] = true,
        ["j_quantum_cd"] = true,
        ["j_quantum_In"] = true,
        ["j_quantum_Sn"] = true,
        ["j_quantum_Sb"] = true,
        ["j_quantum_Te"] = true,
        ["j_quantum_Cs"] = true,
        ["j_quantum_La"] = true,
        ["j_quantum_Ce"] = true,
        ["j_quantum_Pr"] = true,
        ["j_quantum_Nd"] = true,
        ["j_quantum_Pm"] = true,
        ["j_quantum_Sm"] = true,
        ["j_quantum_Eu"] = true,
        ["j_quantum_Gd"] = true,
        ["j_quantum_Tb"] = true,
        ["j_quantum_Dy"] = true,
        ["j_quantum_Ho"] = true,
        ["j_quantum_Er"] = true,
        ["j_quantum_Tm"] = true,
        ["j_quantum_ytterbium"] = true,
        ["j_quantum_metallicglass"] = true,
        ["j_quantum_Lu"] = true,
        ["j_quantum_Hf"] = true,
        ["j_quantum_Ta"] = true,
        ["j_quantum_highentropyalloy"] = true,
        ["j_quantum_W"] = true,
        ["j_quantum_Re"] = true
    },
})

SMODS.ObjectType({
    key = "quantum_util",
    cards = {
        ["j_quantum_N"] = true,
        ["j_quantum_Bitcoin"] = true,
        ["j_quantum_ETH"] = true,
        ["j_quantum_Weak"] = true,
        ["j_quantum_MTO"] = true,
        ["j_quantum_gravity"] = true,
        ["j_quantum_gluon"] = true,
        ["j_quantum_Mg"] = true,
        ["j_quantum_Al"] = true,
        ["j_quantum_S"] = true,
        ["j_quantum_Ca"] = true,
        ["j_quantum_Ti"] = true,
        ["j_quantum_V"] = true,
        ["j_quantum_Sn"] = true,
        ["j_quantum_I"] = true,
        ["j_quantum_Cs"] = true,
        ["j_quantum_Ba"] = true,
        ["j_quantum_Tb"] = true
    },
})

SMODS.ObjectType({
    key = "quantum_misc",
    cards = {
        ["j_quantum_TBL"] = true,
        ["j_quantum_FP"] = true,
        ["j_quantum_Bitcoin"] = true,
        ["j_quantum_ETH"] = true,
        ["j_quantum_FractalGeometry"] = true,
        ["j_quantum_NeutronStar"] = true,
        ["j_quantum_MTO"] = true,
        ["j_quantum_reportcard"] = true,
        ["j_quantum_BlackHole"] = true,
        ["j_quantum_DyingStar"] = true,
        ["j_quantum_SupermassiveStar"] = true,
        ["j_quantum_star"] = true,
        ["j_quantum_67"] = true,
        ["j_quantum_meme"] = true,
        ["j_quantum_taxreturns"] = true,
        ["j_quantum_loan"] = true,
        ["j_quantum_glassshards"] = true,
        ["j_quantum_metallicglass"] = true,
        ["j_quantum_paytowin"] = true,
        ["j_quantum_wip"] = true,
        ["j_quantum_savings"] = true,
        ["j_quantum_timedilation"] = true,
        ["j_quantum_thematrix"] = true
    },
})

SMODS.ObjectType({
    key = "quantum_states",
    cards = {
        ["j_quantum_solidstate"] = true
    },
})

SMODS.ObjectType({
    key = "quantum_state",
    cards = {
        ["j_quantum_liquidstate"] = true,
        ["j_quantum_gaseousstate"] = true,
        ["j_quantum_superfluidity"] = true
    },
})

SMODS.ObjectType({
    key = "quantum_quantum_jokers",
    cards = {
        ["j_quantum_67"] = true,
        ["j_quantum_glassshards"] = true,
        ["j_quantum_metallicglass"] = true,
        ["j_quantum_cryptowallet"] = true,
        ["j_quantum_Lu"] = true,
        ["j_quantum_Hf"] = true,
        ["j_quantum_Ta"] = true,
        ["j_quantum_paytowin"] = true,
        ["j_quantum_wip"] = true,
        ["j_quantum_savings"] = true,
        ["j_quantum_timedilation"] = true,
        ["j_quantum_thematrix"] = true,
        ["j_quantum_highentropyalloy"] = true,
        ["j_quantum_W"] = true,
        ["j_quantum_Re"] = true
    },
})

SMODS.ObjectType({
    key = "quantum_elemen",
    cards = {
        ["j_quantum_Ga"] = true
    },
})

SMODS.ObjectType({
    key = "quantum_special",
    cards = {
        ["j_quantum_cryptowallet"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {},
        post_trigger = true 
    }
end