
SMODS.Seal {
    key = 'relative',
    pos = { x = 1, y = 1 },
    config = {
        extra = {
            xchips0 = 1.75
        }
    },
    badge_colour = HEX('000000'),
    loc_txt = {
        name = 'Relative',
        label = 'Relative',
        text = {
            [1] = 'when playing at 0.5X game speed',
            [2] = 'this card gives {X:chips,C:white}×1.75{} {C:blue}Chips{}'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = false,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play and to_big(G.SETTINGS.GAMESPEED) == to_big(0.5) then
            return {
                x_chips = 1.75
            }
        end
    end
}