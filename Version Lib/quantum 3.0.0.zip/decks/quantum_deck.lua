
SMODS.Back {
    key = 'quantum_deck',
    pos = { x = 2, y = 1 },
    config = {
    },
    loc_txt = {
        name = 'Quantum Deck',
        text = {
            [1] = 'Only Modded jokers appear',
            [2] = 'cuz everyone\'s here!',
            [3] = '{C:red}STILL WORK IN PROGRESS{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    
}