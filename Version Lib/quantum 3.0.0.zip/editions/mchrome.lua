
SMODS.Shader({ key = 'monochrome', path = 'monochrome.fs' })

SMODS.Edition {
    key = 'mchrome',
    shader = 'monochrome',
    config = {
        extra = {
            currentscoringchips = 0,
            currentscoringmult = 0,
            x = 0
        }
    },
    in_shop = true,
    weight = 2,
    extra_cost = 5,
    apply_to_float = false,
    badge_colour = HEX('00c2a2'),
    sound = { sound = "polychrome1", per = 1.5, vol = 0.4 },
    disable_shadow = true,
    disable_base_shader = false,
    loc_txt = {
        name = 'Mathematically Chromatic',
        label = 'Mathematically Chromatic',
        text = {
            [1] = 'take the current Mult, Multiply it by',
            [2] = 'the current Chips. divide that by Pi,',
            [3] = 'then take the natural logarithm,',
            [4] = 'square the value and take the natural',
            [5] = 'logarithm and then take the square',
            [6] = 'root of that value as {C:red}XMult{}.',
            [7] = 'Current {C:red}XMult{} {C:white}..{} {X:red,C:white}#1#{}'
        }
    },
    unlocked = true,
    discovered = false,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.x, hand_chips, mult}}
    end,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if (context.pre_joker or (context.main_scoring and context.cardarea == G.play)) then
            local x_value = card.ability.extra.x
            card.ability.extra.x = hand_chips
            card.ability.extra.x = (card.ability.extra.x) * mult
            card.ability.extra.x = (card.ability.extra.x) / 3.141592653589793
            card.ability.extra.x = math.log(card.ability.extra.x)
            card.ability.extra.x = (card.ability.extra.x) * card.ability.edition.x
            card.ability.extra.x = math.log(card.ability.extra.x)
            card.ability.extra.x = math.sqrt(card.ability.extra.x)
            return {
                Xmult = x_value
            }
        end
    end
}