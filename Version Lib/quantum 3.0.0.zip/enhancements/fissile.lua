
SMODS.Enhancement {
    key = 'fissile',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            odds = 20,
            xmult0 = 2,
            xchips0 = 1.1
        }
    },
    loc_txt = {
        name = 'Fissile',
        text = {
            [1] = '{C:green}65%{} chance to give {X:red,C:white}×2{} {C:red}Mult{}',
            [2] = '{C:green}35%{} chance to give {X:blue,C:white}×1.1{} {C:blue}Chips{}',
            [3] = 'when this card is scored.'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = false,
    no_collection = false,
    weight = 1.25,
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_dd5f134a', 13, card.ability.extra.odds, 'j_quantum_fissile', false) then
                SMODS.calculate_effect({Xmult = 2}, card)
            end
            if SMODS.pseudorandom_probability(card, 'group_1_adf6ae9f', 7, card.ability.extra.odds, 'j_quantum_fissile', false) then
                SMODS.calculate_effect({x_chips = 1.1}, card)
            end
        end
    end
}