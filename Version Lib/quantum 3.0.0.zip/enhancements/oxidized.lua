
SMODS.Enhancement {
    key = 'oxidized',
    pos = { x = 3, y = 0 },
    config = {
        extra = {
            blindchiprequirement = 0,
            currentscoringchips = 0,
            currentscoringmult = 0,
            x = 0,
            y = 0,
            dollars0 = 1,
            odds = 2,
            levels0 = 1
        }
    },
    loc_txt = {
        name = 'Oxidized',
        text = {
            [1] = 'If the score is on fire',
            [2] = '{C:money}+1${} and a {C:green}50/50{} to',
            [3] = 'level up the current hand'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = false,
    no_collection = false,
    weight = 2,
    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.x, card.ability.extra.y, (G.GAME.blind.chips or 0), hand_chips, mult}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            local y_value = card.ability.extra.y
            card.ability.extra.x = G.GAME.blind.chips
            card.ability.extra.y = hand_chips
            card.ability.extra.y = (card.ability.extra.y) * mult
            card.ability.extra.y = (card.ability.extra.y) * 1.75
        end
        if context.main_scoring and context.cardarea == G.play and to_big((card.ability.extra.y or 0)) > to_big(card.ability.extra.x) then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + 1
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "+"..tostring(1), colour = G.C.MONEY})
                    return true
                end
                ,
                func = function()
                    if SMODS.pseudorandom_probability(card, 'group_0_62418e3f', 1, card.ability.extra.odds, 'j_quantum_oxidized', false) then
                        local target_hand
                        target_hand = context.scoring_name or "High Card"
                        SMODS.calculate_effect({level_up = 1,
                        level_up_hand = target_hand}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_level_up_ex'), colour = G.C.RED})
                    end
                    return true
                end
            }
        end
    end
}