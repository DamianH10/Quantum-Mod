
SMODS.Joker{ --Blue Pill
    key = "bluepill",
    config = {
        extra = {
            xchips0 = 1.82
        }
    },
    loc_txt = {
        ['name'] = 'Blue Pill',
        ['text'] = {
            [1] = 'Take the Blue Pill',
            [2] = 'Matrix cards give',
            [3] = '{X:blue,C:white}×1.82{} {C:blue}Chips{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 15
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_misc"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_quantum_matrix"] == true then
                return {
                    x_chips = 1.82
                }
            end
        end
    end
}