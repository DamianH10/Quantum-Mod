
SMODS.Joker{ --Gas mask
    key = "gasmask",
    config = {
        extra = {
            xmult0 = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'Gas mask',
        ['text'] = {
            [1] = 'Toxic cards give',
            [2] = '{X:red,C:white}×2.5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_misc"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_quantum_toxic"] == true then
                return {
                    Xmult = 2.5
                }
            end
        end
    end
}