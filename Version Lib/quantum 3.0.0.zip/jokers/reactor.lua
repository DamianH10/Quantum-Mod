
SMODS.Joker{ --Reactor
    key = "reactor",
    config = {
        extra = {
            xmult0 = 2,
            xchips0 = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'Reactor',
        ['text'] = {
            [1] = 'Fissile cards give {X:red,C:white}×2{} {C:red}Mult{}',
            [2] = 'and {X:blue,C:white}×2.5{} {C:blue}Chips{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "quantum_ultra_rare",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_misc"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_quantum_fissile"] == true then
                return {
                    Xmult = 2,
                    extra = {
                        x_chips = 2.5,
                        colour = G.C.DARK_EDITION
                    }
                }
            end
        end
    end
}