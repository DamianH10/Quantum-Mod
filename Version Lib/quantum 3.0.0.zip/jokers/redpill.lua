
SMODS.Joker{ --Red Pill
    key = "redpill",
    config = {
        extra = {
            xmult0 = 1.82
        }
    },
    loc_txt = {
        ['name'] = 'Red Pill',
        ['text'] = {
            [1] = 'Take the Red pill',
            [2] = 'Played matrix cards',
            [3] = 'give {X:red,C:white}×1.82{} {C:red}Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quantum_quantum_jokers"] = true, ["quantum_misc"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_quantum_matrix"] == true then
                return {
                    Xmult = 1.82
                }
            end
        end
    end
}